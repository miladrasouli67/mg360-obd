package ir.obd.mg360;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.view.View;

/** Horizontal segmented bar (used for coolant temperature in the "classic" layout). */
public class BarGaugeView extends View {

    private final String label;
    private final String unit;
    private final float min, max;
    private float warnFrom;
    private float value = Float.NaN;
    private float shown;

    private final Paint seg = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint labelP = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint valueP = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final RectF r = new RectF();

    public BarGaugeView(Context ctx, String label, String unit, float min, float max, float warnFrom) {
        super(ctx);
        this.label = label;
        this.unit = unit;
        this.min = min;
        this.max = max;
        this.warnFrom = warnFrom;
        this.shown = min;
        labelP.setColor(Color.parseColor("#8C98A6"));
        labelP.setTypeface(Typeface.create("sans-serif-medium", Typeface.NORMAL));
        labelP.setTextAlign(Paint.Align.RIGHT);
        valueP.setTypeface(Typeface.create("sans-serif-condensed", Typeface.BOLD));
        valueP.setTextAlign(Paint.Align.LEFT);
    }

    public void setWarnFrom(float v) {
        warnFrom = v;
        invalidate();
    }

    public void setValue(float v) {
        value = v;
        postInvalidateOnAnimation();
    }

    private int colorFor(float v) {
        if (v >= warnFrom) return Color.parseColor("#FF1744");
        if (v >= warnFrom - 10) return Color.parseColor("#FFC400");
        if (v >= 70) return Color.parseColor("#00E676");
        return Color.parseColor("#2979FF");
    }

    @Override
    protected void onDraw(Canvas c) {
        super.onDraw(c);
        float w = getWidth(), h = getHeight();
        float barH = h * 0.24f;
        float top = h - barH;

        boolean has = !Float.isNaN(value);
        float goal = has ? value : min;
        float diff = goal - shown;
        if (Math.abs(diff) > (max - min) * 0.002f) {
            shown += diff * 0.2f;
            postInvalidateOnAnimation();
        } else shown = goal;

        labelP.setTextSize(h * 0.30f);
        c.drawText(label, w, top - h * 0.14f, labelP);
        valueP.setTextSize(h * 0.48f);
        valueP.setColor(has && value >= warnFrom ? Color.parseColor("#FF4D4D") : Color.WHITE);
        c.drawText(has ? Math.round(value) + unit : "--", 0, top - h * 0.12f, valueP);

        int segs = 30;
        float gap = Math.max(2f, w * 0.008f);
        float sw = (w - gap * (segs - 1)) / segs;
        float f = (Math.max(min, Math.min(max, shown)) - min) / (max - min);
        for (int i = 0; i < segs; i++) {
            float t = i / (float) (segs - 1);
            float v = min + t * (max - min);
            seg.setColor(has && t <= f ? colorFor(v) : Color.parseColor("#1B232D"));
            r.set(i * (sw + gap), top, i * (sw + gap) + sw, h);
            c.drawRoundRect(r, 2, 2, seg);
        }
    }
}
