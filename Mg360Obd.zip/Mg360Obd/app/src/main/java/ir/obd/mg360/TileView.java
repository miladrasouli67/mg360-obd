package ir.obd.mg360;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.Typeface;
import android.view.View;

/** Small digital readout card with an optional progress bar along the bottom. */
public class TileView extends View {

    private final String label;
    private final String unit;
    private final int accent;
    private final boolean showBar;

    private String value = "--";
    private float barFraction = 0f;
    private float barShown = 0f;
    private int valueColor = Color.WHITE;

    private final Paint bg = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint border = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint labelP = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint valueP = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint unitP = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint barBg = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint bar = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint accentP = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final RectF r = new RectF();

    public TileView(Context ctx, String label, String unit, int accent, boolean showBar) {
        super(ctx);
        this.label = label;
        this.unit = unit;
        this.accent = accent;
        this.showBar = showBar;

        border.setStyle(Paint.Style.STROKE);
        border.setColor(Color.parseColor("#1E2833"));
        labelP.setColor(Color.parseColor("#8C98A6"));
        labelP.setTypeface(Typeface.create("sans-serif-medium", Typeface.NORMAL));
        valueP.setTypeface(Typeface.create("sans-serif-condensed", Typeface.BOLD));
        unitP.setColor(Color.parseColor("#6B7785"));
        unitP.setTypeface(Typeface.create("sans-serif-light", Typeface.NORMAL));
        barBg.setColor(Color.parseColor("#1B232D"));
        accentP.setColor(accent);
    }

    public void setValue(String v) {
        value = v == null ? "--" : v;
        invalidate();
    }

    public void setBar(float fraction) {
        barFraction = Math.max(0f, Math.min(1f, fraction));
        postInvalidateOnAnimation();
    }

    public void setValueColor(int c) {
        valueColor = c;
        invalidate();
    }

    @Override
    protected void onSizeChanged(int w, int h, int ow, int oh) {
        super.onSizeChanged(w, h, ow, oh);
        bg.setShader(new LinearGradient(0, 0, 0, h, 0xD9141B23, 0xCC0C1116,
                Shader.TileMode.CLAMP));
        bar.setShader(new LinearGradient(0, 0, w, 0, (accent & 0x00FFFFFF) | 0x80000000, accent,
                Shader.TileMode.CLAMP));
    }

    @Override
    protected void onDraw(Canvas c) {
        super.onDraw(c);
        float w = getWidth(), h = getHeight();
        float d = getResources().getDisplayMetrics().density;
        float pad = 4 * d;
        float corner = 14 * d;
        r.set(pad, pad, w - pad, h - pad);
        c.drawRoundRect(r, corner, corner, bg);
        border.setStrokeWidth(1 * d);
        c.drawRoundRect(r, corner, corner, border);

        // accent strip on the right edge (RTL start)
        float stripH = (h - 2 * pad) * 0.38f;
        r.set(w - pad - 3 * d, pad + (h - 2 * pad - stripH) / 2, w - pad, pad + (h - 2 * pad + stripH) / 2);
        c.drawRoundRect(r, 2 * d, 2 * d, accentP);

        float inner = h - 2 * pad;
        float x = w - pad - 14 * d;

        labelP.setTextSize(inner * 0.17f);
        labelP.setTextAlign(Paint.Align.RIGHT);
        float lw = labelP.measureText(label), lavail = x - (pad + 10 * d);
        if (lw > lavail && lw > 0) labelP.setTextSize(labelP.getTextSize() * lavail / lw);
        c.drawText(label, x, pad + inner * 0.28f, labelP);

        valueP.setTextSize(inner * 0.44f);
        valueP.setColor(valueColor);
        valueP.setTextAlign(Paint.Align.RIGHT);
        unitP.setTextSize(inner * 0.16f);
        // shrink the number if number + unit do not fit in the card
        float avail = x - (pad + 10 * d);
        float need = valueP.measureText(value) + 6 * d + unitP.measureText(unit);
        if (need > avail && need > 0) {
            float k = avail / need;
            valueP.setTextSize(valueP.getTextSize() * k);
            unitP.setTextSize(unitP.getTextSize() * k);
        }
        float vy = pad + inner * (showBar ? 0.72f : 0.80f);
        c.drawText(value, x, vy, valueP);

        float vw = valueP.measureText(value);
        unitP.setTextAlign(Paint.Align.RIGHT);
        c.drawText(unit, x - vw - 6 * d, vy, unitP);

        if (showBar) {
            float diff = barFraction - barShown;
            if (Math.abs(diff) > 0.002f) {
                barShown += diff * 0.25f;
                postInvalidateOnAnimation();
            } else barShown = barFraction;
            float bh = Math.max(3 * d, inner * 0.06f);
            float left = pad + 14 * d, right = x;
            float top = pad + inner * 0.84f;
            r.set(left, top, right, top + bh);
            c.drawRoundRect(r, bh / 2, bh / 2, barBg);
            if (barShown > 0.005f) {
                // fills from right to left (RTL)
                r.set(right - (right - left) * barShown, top, right, top + bh);
                c.drawRoundRect(r, bh / 2, bh / 2, bar);
            }
        }
    }
}
