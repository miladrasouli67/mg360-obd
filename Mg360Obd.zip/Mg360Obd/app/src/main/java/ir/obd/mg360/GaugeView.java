package ir.obd.mg360;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.RadialGradient;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.SweepGradient;
import android.graphics.Matrix;
import android.graphics.Typeface;
import android.view.View;

import java.util.Locale;

/**
 * Round automotive gauge: glowing value arc, tick scale, needle, big digital value in the centre.
 * The needle glides smoothly towards the latest value (updated every frame).
 */
public class GaugeView extends View {

    private static final float START = 135f;   // degrees, 0 = 3 o'clock
    private static final float SWEEP = 270f;

    private final String title;
    private final String unit;
    private final float min, max;
    private final float majorStep;
    private final int decimals;
    private final int[] arcColors;
    private float redFrom;            // values >= redFrom are drawn in the red zone
    private float labelDivider = 1f;  // e.g. 1000 to print "1 2 3" on an rpm scale

    private float target;
    private float shown;
    private boolean hasValue = false;
    private float peak = Float.NaN;
    private boolean showPeak = false;
    private boolean digitalCenter = false;
    private String gearText = null;
    private final Paint gearBg = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint gearStroke = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint gearP = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint gearLabel = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint comet = new Paint(Paint.ANTI_ALIAS_FLAG);
    private String subText = "";
    private int valueColorOverride = 0;

    private final Paint track = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint arc = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint glow = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint red = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint tick = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint tickLabel = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint needle = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint hub = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint valueText = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint unitText = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint titleText = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint face = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint rim = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint peakPaint = new Paint(Paint.ANTI_ALIAS_FLAG);

    private final RectF oval = new RectF();
    private final RectF tmp = new RectF();
    private float cx, cy, radius;

    public GaugeView(Context ctx, String title, String unit, float min, float max, float majorStep,
                     int decimals, int[] arcColors) {
        super(ctx);
        this.title = title;
        this.unit = unit;
        this.min = min;
        this.max = max;
        this.majorStep = majorStep;
        this.decimals = decimals;
        this.arcColors = arcColors;
        this.redFrom = Float.NaN;
        this.target = min;
        this.shown = min;

        Typeface cond = Typeface.create("sans-serif-condensed", Typeface.BOLD);
        Typeface light = Typeface.create("sans-serif-light", Typeface.NORMAL);

        track.setStyle(Paint.Style.STROKE);
        track.setStrokeCap(Paint.Cap.BUTT);
        track.setColor(Color.parseColor("#1B232D"));

        arc.setStyle(Paint.Style.STROKE);
        arc.setStrokeCap(Paint.Cap.BUTT);

        glow.setStyle(Paint.Style.STROKE);
        glow.setStrokeCap(Paint.Cap.BUTT);

        red.setStyle(Paint.Style.STROKE);
        red.setColor(Color.parseColor("#55FF2D2D"));

        tick.setStyle(Paint.Style.STROKE);
        tick.setStrokeCap(Paint.Cap.ROUND);

        tickLabel.setColor(Color.parseColor("#8C98A6"));
        tickLabel.setTextAlign(Paint.Align.CENTER);
        tickLabel.setTypeface(cond);

        needle.setStyle(Paint.Style.FILL);
        needle.setColor(Color.parseColor("#FF3B30"));

        hub.setStyle(Paint.Style.FILL);

        valueText.setColor(Color.WHITE);
        valueText.setTextAlign(Paint.Align.CENTER);
        valueText.setTypeface(cond);

        unitText.setColor(Color.parseColor("#8C98A6"));
        unitText.setTextAlign(Paint.Align.CENTER);
        unitText.setTypeface(light);

        titleText.setColor(Color.parseColor("#C7D0DA"));
        titleText.setTextAlign(Paint.Align.CENTER);
        titleText.setTypeface(Typeface.create("sans-serif-medium", Typeface.NORMAL));
        titleText.setLetterSpacing(0.12f);

        rim.setStyle(Paint.Style.STROKE);

        peakPaint.setStyle(Paint.Style.FILL);
        peakPaint.setColor(Color.parseColor("#FFD54F"));
    }

    public GaugeView setRedFrom(float v) {
        redFrom = v;
        return this;
    }

    public GaugeView setLabelDivider(float d) {
        labelDivider = d;
        return this;
    }

    /** Hero style: no needle, a large rolling digital readout in the middle and a glowing tip on the arc. */
    public GaugeView setDigitalCenter(boolean b) {
        digitalCenter = b;
        return this;
    }

    /** Gear shown under the unit of the hero speedometer; null hides it. */
    public void setGear(String g) {
        if (g == null ? gearText == null : g.equals(gearText)) return;
        gearText = g;
        invalidate();
    }

    public GaugeView setShowPeak(boolean b) {
        showPeak = b;
        return this;
    }

    public void resetPeak() {
        peak = Float.NaN;
        invalidate();
    }

    public float getPeak() {
        return peak;
    }

    /** Sets a new reading; pass Float.NaN when no data is available. */
    public void setValue(float v) {
        if (Float.isNaN(v)) {
            hasValue = false;
        } else {
            hasValue = true;
            target = v;
            if (showPeak && (Float.isNaN(peak) || v > peak)) peak = v;
        }
        postInvalidateOnAnimation();
    }

    public void setSubText(String s) {
        subText = s == null ? "" : s;
        invalidate();
    }

    /** 0 = automatic colour. */
    public void setValueColor(int c) {
        valueColorOverride = c;
        invalidate();
    }

    @Override
    protected void onSizeChanged(int w, int h, int oldw, int oldh) {
        super.onSizeChanged(w, h, oldw, oldh);
        float size = Math.min(w, h);
        radius = size / 2f * 0.86f;
        cx = w / 2f;
        cy = h / 2f;
        float sw = radius * 0.11f;
        oval.set(cx - radius, cy - radius, cx + radius, cy + radius);

        track.setStrokeWidth(sw);
        arc.setStrokeWidth(sw);
        glow.setStrokeWidth(sw * 2.4f);
        red.setStrokeWidth(sw * 0.35f);
        tick.setStrokeWidth(radius * 0.012f);
        tickLabel.setTextSize(radius * 0.13f);
        valueText.setTextSize(radius * 0.40f);
        unitText.setTextSize(radius * 0.11f);
        titleText.setTextSize(radius * 0.11f);
        rim.setStrokeWidth(radius * 0.02f);

        // Arc gradient, rotated so it starts at the beginning of the scale
        float[] pos = new float[arcColors.length];
        for (int i = 0; i < pos.length; i++) {
            pos[i] = (2f + SWEEP * i / Math.max(1, pos.length - 1)) / 360f;
        }
        SweepGradient sg = new SweepGradient(cx, cy, arcColors, pos);
        Matrix m = new Matrix();
        m.setRotate(START - 2, cx, cy);
        sg.setLocalMatrix(m);
        arc.setShader(sg);
        SweepGradient sg2 = new SweepGradient(cx, cy, withAlpha(arcColors, 0x40), pos);
        sg2.setLocalMatrix(m);
        glow.setShader(sg2);

        face.setShader(new RadialGradient(cx, cy, radius * 1.15f,
                new int[]{Color.parseColor("#151C24"), Color.parseColor("#0B0F14"), Color.parseColor("#06080B")},
                new float[]{0f, 0.75f, 1f}, Shader.TileMode.CLAMP));
        rim.setShader(new LinearGradient(cx, cy - radius, cx, cy + radius,
                Color.parseColor("#3A4654"), Color.parseColor("#0E1217"), Shader.TileMode.CLAMP));
        hub.setShader(new RadialGradient(cx, cy, radius * 0.09f,
                Color.parseColor("#3A4350"), Color.parseColor("#0E1217"), Shader.TileMode.CLAMP));
    }

    private static int[] withAlpha(int[] colors, int alpha) {
        int[] out = new int[colors.length];
        for (int i = 0; i < colors.length; i++) out[i] = (colors[i] & 0x00FFFFFF) | (alpha << 24);
        return out;
    }

    private float angleFor(float v) {
        float f = (Math.max(min, Math.min(max, v)) - min) / (max - min);
        return START + SWEEP * f;
    }

    @Override
    protected void onDraw(Canvas c) {
        super.onDraw(c);
        if (radius <= 0) return;

        // Smoothly glide towards the target
        float goal = hasValue ? target : min;
        float diff = goal - shown;
        if (Math.abs(diff) > (max - min) * 0.0008f) {
            shown += diff * 0.22f;
            postInvalidateOnAnimation();
        } else {
            shown = goal;
        }

        // Face
        c.drawCircle(cx, cy, radius * 1.13f, face);
        c.drawCircle(cx, cy, radius * 1.13f, rim);

        // Track
        c.drawArc(oval, START, SWEEP, false, track);

        // Red zone
        if (!Float.isNaN(redFrom) && redFrom < max) {
            float a0 = angleFor(redFrom);
            float r2 = radius * 0.87f;
            tmp.set(cx - r2, cy - r2, cx + r2, cy + r2);
            c.drawArc(tmp, a0, START + SWEEP - a0, false, red);
        }

        // Value arc + glow
        float a = angleFor(shown);
        float sweep = a - START;
        if (sweep > 0.3f) {
            c.drawArc(oval, START, sweep, false, glow);
            c.drawArc(oval, START, sweep, false, arc);
        }

        // Ticks and labels
        int minorPerMajor = 5;
        float minorStep = majorStep / minorPerMajor;
        int n = Math.round((max - min) / minorStep);
        for (int i = 0; i <= n; i++) {
            float v = min + i * minorStep;
            boolean major = i % minorPerMajor == 0;
            double rad = Math.toRadians(angleFor(v));
            float cos = (float) Math.cos(rad), sin = (float) Math.sin(rad);
            float r1 = radius * (major ? 0.78f : 0.83f);
            float r2 = radius * 0.88f;
            boolean inRed = !Float.isNaN(redFrom) && v >= redFrom;
            tick.setColor(inRed ? Color.parseColor("#FF4D4D") : (major ? Color.parseColor("#D6DEE7") : Color.parseColor("#4A5562")));
            tick.setStrokeWidth(radius * (major ? 0.018f : 0.009f));
            c.drawLine(cx + cos * r1, cy + sin * r1, cx + cos * r2, cy + sin * r2, tick);
            if (major) {
                float lr = radius * 0.64f;
                String label = formatLabel(v / labelDivider);
                tickLabel.setColor(inRed ? Color.parseColor("#FF6B6B") : Color.parseColor("#8C98A6"));
                c.drawText(label, cx + cos * lr, cy + sin * lr + tickLabel.getTextSize() * 0.35f, tickLabel);
            }
        }

        // Peak marker
        if (showPeak && !Float.isNaN(peak)) {
            double pr = Math.toRadians(angleFor(peak));
            float pr1 = radius * 1.0f;
            c.drawCircle(cx + (float) Math.cos(pr) * pr1, cy + (float) Math.sin(pr) * pr1, radius * 0.035f, peakPaint);
        }

        if (digitalCenter) {
            drawDigitalCenter(c, a);
            return;
        }

        // Title above centre
        c.drawText(title, cx, cy - radius * 0.30f, titleText);

        // Digital value
        String txt = hasValue ? format(target) : "--";
        int col;
        if (valueColorOverride != 0) col = valueColorOverride;
        else if (hasValue && !Float.isNaN(redFrom) && target >= redFrom) col = Color.parseColor("#FF4D4D");
        else col = Color.WHITE;
        valueText.setColor(col);
        c.drawText(txt, cx, cy + radius * 0.88f, valueText);
        c.drawText(subText.isEmpty() ? unit : unit + "  ·  " + subText, cx, cy + radius * 1.05f, unitText);

        // Needle (drawn last, slim tapered)
        double nr = Math.toRadians(a);
        float ncos = (float) Math.cos(nr), nsin = (float) Math.sin(nr);
        float tipR = radius * 0.86f, tailR = radius * 0.14f, halfW = radius * 0.028f;
        float px = -nsin, py = ncos; // perpendicular
        android.graphics.Path p = new android.graphics.Path();
        p.moveTo(cx + ncos * tipR, cy + nsin * tipR);
        p.lineTo(cx + px * halfW - ncos * tailR, cy + py * halfW - nsin * tailR);
        p.lineTo(cx - px * halfW - ncos * tailR, cy - py * halfW - nsin * tailR);
        p.close();
        needle.setColor(hasValue ? Color.parseColor("#FF3B30") : Color.parseColor("#4A5562"));
        c.drawPath(p, needle);
        c.drawCircle(cx, cy, radius * 0.085f, hub);
    }

    private void drawDigitalCenter(Canvas c, float a) {
        // glowing tip at the end of the arc
        if (hasValue) {
            double r = Math.toRadians(a);
            float tx = cx + (float) Math.cos(r) * radius, ty = cy + (float) Math.sin(r) * radius;
            comet.setShader(new RadialGradient(tx, ty, radius * 0.16f,
                    new int[]{Color.WHITE, (tipColor() & 0x00FFFFFF) | 0x90000000, 0x00000000},
                    new float[]{0f, 0.35f, 1f}, Shader.TileMode.CLAMP));
            c.drawCircle(tx, ty, radius * 0.16f, comet);
        }
        c.drawText(title, cx, cy - radius * 0.40f, titleText);

        String txt = hasValue ? String.valueOf(Math.round(shown)) : "--";
        int col = (hasValue && !Float.isNaN(redFrom) && target >= redFrom) ? Color.parseColor("#FF4D4D") : Color.WHITE;
        float old = valueText.getTextSize();
        valueText.setTextSize(radius * 0.62f);
        valueText.setColor(col);
        c.drawText(txt, cx, cy + radius * 0.20f, valueText);
        valueText.setTextSize(old);
        float oldU = unitText.getTextSize();
        unitText.setTextSize(radius * 0.13f);
        c.drawText(subText.isEmpty() ? unit : unit + "  ·  " + subText, cx, cy + radius * 0.42f, unitText);
        unitText.setTextSize(oldU);
        drawGear(c);
        if (hasValue && Math.abs(goalDiff()) > 0.5f) postInvalidateOnAnimation();
    }

    /** Rounded "gear" badge below km/h. */
    private void drawGear(Canvas c) {
        if (gearText == null) return;
        float h = radius * 0.30f, w = radius * 0.30f;
        float top = cy + radius * 0.56f;
        RectF box = new RectF(cx - w / 2, top, cx + w / 2, top + h);
        gearBg.setShader(new LinearGradient(0, box.top, 0, box.bottom,
                Color.parseColor("#1E2A36"), Color.parseColor("#0C1116"), Shader.TileMode.CLAMP));
        c.drawRoundRect(box, h * 0.28f, h * 0.28f, gearBg);
        gearStroke.setStyle(Paint.Style.STROKE);
        gearStroke.setStrokeWidth(radius * 0.012f);
        gearStroke.setColor(Color.parseColor("#9900E5FF"));
        c.drawRoundRect(box, h * 0.28f, h * 0.28f, gearStroke);
        gearP.setTextAlign(Paint.Align.CENTER);
        gearP.setTypeface(Typeface.create("sans-serif-condensed", Typeface.BOLD));
        gearP.setTextSize(h * 0.78f);
        gearP.setColor(Color.parseColor("#00E5FF"));
        c.drawText(gearText, cx, box.top + h * 0.78f, gearP);
        gearLabel.setTextAlign(Paint.Align.CENTER);
        gearLabel.setTextSize(radius * 0.075f);
        gearLabel.setColor(Color.parseColor("#6B7785"));
        gearLabel.setLetterSpacing(0.2f);
        c.drawText("GEAR", cx, box.bottom + radius * 0.10f, gearLabel);
    }

    private float goalDiff() {
        return target - shown;
    }

    private int tipColor() {
        float f = (Math.max(min, Math.min(max, shown)) - min) / (max - min);
        int i = Math.min(arcColors.length - 1, Math.round(f * (arcColors.length - 1)));
        return arcColors[i];
    }

    private String format(float v) {
        if (decimals == 0) return String.valueOf(Math.round(v));
        return String.format(Locale.US, "%." + decimals + "f", v);
    }

    private String formatLabel(float v) {
        if (Math.abs(v - Math.round(v)) < 0.001f) return String.valueOf(Math.round(v));
        return String.format(Locale.US, "%.1f", v);
    }
}
