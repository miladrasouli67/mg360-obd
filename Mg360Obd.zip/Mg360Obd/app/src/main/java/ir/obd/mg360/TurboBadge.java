package ir.obd.mg360;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RadialGradient;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.SweepGradient;
import android.view.View;

/**
 * The app's own emblem: a turbine wheel inside a ring. If the user picked a custom image
 * in settings, that image is shown instead. The wheel spins faster as boost rises.
 */
public class TurboBadge extends View {

    private Bitmap custom;
    private float rotation = 0f;
    private float speed = 0.4f; // degrees per frame
    private long lastFrame = 0;

    private final Paint ring = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint disc = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint blade = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint hub = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint bmp = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.FILTER_BITMAP_FLAG);
    private final Path bladePath = new Path();
    private final Rect src = new Rect();
    private final RectF dst = new RectF();

    public TurboBadge(Context ctx) {
        super(ctx);
        ring.setStyle(Paint.Style.STROKE);
        blade.setStyle(Paint.Style.FILL);
    }

    public void setCustomImage(Bitmap b) {
        custom = b;
        invalidate();
    }

    /** 0..1 — spins the wheel faster with boost. */
    public void setIntensity(float f) {
        if (Float.isNaN(f)) f = 0f;
        f = Math.max(0f, Math.min(1f, f));
        speed = 0.4f + f * 14f;
        postInvalidateOnAnimation();
    }

    @Override
    protected void onSizeChanged(int w, int h, int ow, int oh) {
        super.onSizeChanged(w, h, ow, oh);
        float cx = w / 2f, cy = h / 2f, r = Math.min(w, h) / 2f;
        SweepGradient sg = new SweepGradient(cx, cy,
                new int[]{Color.parseColor("#00E5FF"), Color.parseColor("#2979FF"), Color.parseColor("#FF6D00"),
                        Color.parseColor("#00E5FF")}, null);
        ring.setShader(sg);
        ring.setStrokeWidth(r * 0.12f);
        disc.setShader(new RadialGradient(cx, cy, r, Color.parseColor("#1C2530"), Color.parseColor("#090C10"),
                Shader.TileMode.CLAMP));
        blade.setShader(new LinearGradient(cx - r, cy - r, cx + r, cy + r, Color.parseColor("#E3EAF2"),
                Color.parseColor("#6E7B8A"), Shader.TileMode.CLAMP));
        hub.setShader(new RadialGradient(cx, cy, r * 0.22f, Color.parseColor("#FFB020"), Color.parseColor("#FF6D00"),
                Shader.TileMode.CLAMP));

        // one curved blade, pointing up
        bladePath.reset();
        bladePath.moveTo(cx, cy - r * 0.18f);
        bladePath.cubicTo(cx + r * 0.10f, cy - r * 0.40f, cx + r * 0.30f, cy - r * 0.55f, cx + r * 0.12f, cy - r * 0.72f);
        bladePath.cubicTo(cx + r * 0.02f, cy - r * 0.55f, cx - r * 0.12f, cy - r * 0.40f, cx - r * 0.10f, cy - r * 0.18f);
        bladePath.close();
    }

    @Override
    protected void onDraw(Canvas c) {
        super.onDraw(c);
        float w = getWidth(), h = getHeight();
        float cx = w / 2f, cy = h / 2f, r = Math.min(w, h) / 2f;

        if (custom != null) {
            src.set(0, 0, custom.getWidth(), custom.getHeight());
            float s = Math.min(w / custom.getWidth(), h / custom.getHeight());
            float bw = custom.getWidth() * s, bh = custom.getHeight() * s;
            dst.set(cx - bw / 2, cy - bh / 2, cx + bw / 2, cy + bh / 2);
            c.drawBitmap(custom, src, dst, bmp);
            return;
        }

        c.drawCircle(cx, cy, r * 0.94f, disc);
        c.drawCircle(cx, cy, r * 0.88f, ring);

        long now = System.currentTimeMillis();
        if (lastFrame != 0) rotation = (rotation + speed * Math.min(4f, (now - lastFrame) / 16f)) % 360f;
        lastFrame = now;

        int blades = 7;
        for (int i = 0; i < blades; i++) {
            c.save();
            c.rotate(rotation + i * 360f / blades, cx, cy);
            c.drawPath(bladePath, blade);
            c.restore();
        }
        c.drawCircle(cx, cy, r * 0.20f, hub);
        postInvalidateOnAnimation();
    }
}
