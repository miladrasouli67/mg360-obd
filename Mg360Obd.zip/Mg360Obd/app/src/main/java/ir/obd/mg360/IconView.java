package ir.obd.mg360;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RadialGradient;
import android.graphics.RectF;
import android.graphics.Shader;
import android.view.MotionEvent;
import android.view.View;

/**
 * Small vector icons drawn in code (no image files): gear, link, radar, warning, unlink.
 * With {@code button = true} it draws a round glossy button behind the icon and spins the gear on tap.
 */
public class IconView extends View {

    public static final int GEAR = 0, LINK = 1, RADAR = 2, WARNING = 3, UNLINK = 4;

    private final int kind;
    private final int color;
    private final boolean button;
    private float spin = 0f;
    private boolean pressed = false;

    private final Paint fill = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint stroke = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint bg = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint ring = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Path path = new Path();
    private final RectF rf = new RectF();

    public IconView(Context ctx, int kind, int color, boolean button) {
        super(ctx);
        this.kind = kind;
        this.color = color;
        this.button = button;
        fill.setStyle(Paint.Style.FILL);
        stroke.setStyle(Paint.Style.STROKE);
        stroke.setStrokeCap(Paint.Cap.ROUND);
        stroke.setStrokeJoin(Paint.Join.ROUND);
        ring.setStyle(Paint.Style.STROKE);
        setClickable(button);
    }

    @Override
    public boolean onTouchEvent(MotionEvent e) {
        if (button) {
            if (e.getAction() == MotionEvent.ACTION_DOWN) {
                pressed = true;
                invalidate();
            } else if (e.getAction() == MotionEvent.ACTION_UP || e.getAction() == MotionEvent.ACTION_CANCEL) {
                pressed = false;
                if (e.getAction() == MotionEvent.ACTION_UP && kind == GEAR) {
                    spin = 0.0001f; // start a short spin animation
                }
                invalidate();
            }
        }
        return super.onTouchEvent(e);
    }

    @Override
    protected void onDraw(Canvas c) {
        super.onDraw(c);
        float w = getWidth(), h = getHeight();
        float cx = w / 2f, cy = h / 2f, r = Math.min(w, h) / 2f;

        float iconR = r;
        if (button) {
            bg.setShader(new RadialGradient(cx, cy - r * 0.3f, r * 1.2f,
                    pressed ? Color.parseColor("#26323E") : Color.parseColor("#1A222C"),
                    Color.parseColor("#0B0F14"), Shader.TileMode.CLAMP));
            c.drawCircle(cx, cy, r * 0.96f, bg);
            ring.setStrokeWidth(r * 0.06f);
            ring.setShader(new LinearGradient(0, 0, w, h,
                    new int[]{(color & 0x00FFFFFF) | 0xCC000000, 0x33FFFFFF, (color & 0x00FFFFFF) | 0x55000000},
                    null, Shader.TileMode.CLAMP));
            c.drawCircle(cx, cy, r * 0.92f, ring);
            iconR = r * 0.58f;
        }

        fill.setShader(new LinearGradient(cx - iconR, cy - iconR, cx + iconR, cy + iconR,
                Color.WHITE, color, Shader.TileMode.CLAMP));
        stroke.setShader(null);
        stroke.setColor(color);
        stroke.setStrokeWidth(iconR * 0.16f);

        switch (kind) {
            case GEAR:
                drawGear(c, cx, cy, iconR);
                break;
            case LINK:
                drawLink(c, cx, cy, iconR, false);
                break;
            case UNLINK:
                drawLink(c, cx, cy, iconR, true);
                break;
            case RADAR:
                drawRadar(c, cx, cy, iconR);
                break;
            case WARNING:
                drawWarning(c, cx, cy, iconR);
                break;
        }
    }

    private void drawGear(Canvas c, float cx, float cy, float r) {
        if (spin > 0f) {
            spin += 9f;
            if (spin >= 90f) spin = 0f;
            else postInvalidateOnAnimation();
        }
        int teeth = 8;
        float outer = r * 0.98f, inner = r * 0.74f;
        path.reset();
        for (int i = 0; i < teeth; i++) {
            double base = Math.toRadians(spin + i * 360.0 / teeth);
            double half = Math.toRadians(360.0 / teeth / 2);
            double t = half * 0.55; // tooth half-width
            double[] angs = {base - half, base - t * 1.15, base - t * 0.75, base + t * 0.75, base + t * 1.15, base + half};
            float[] rads = {inner, inner, outer, outer, inner, inner};
            for (int k = 0; k < angs.length; k++) {
                float x = cx + (float) Math.cos(angs[k]) * rads[k];
                float y = cy + (float) Math.sin(angs[k]) * rads[k];
                if (i == 0 && k == 0) path.moveTo(x, y);
                else path.lineTo(x, y);
            }
        }
        path.close();
        path.addCircle(cx, cy, r * 0.30f, Path.Direction.CCW); // hole
        path.setFillType(Path.FillType.EVEN_ODD);
        c.drawPath(path, fill);
        // inner ring detail
        stroke.setStrokeWidth(r * 0.07f);
        stroke.setColor((color & 0x00FFFFFF) | 0x99000000);
        c.drawCircle(cx, cy, r * 0.48f, stroke);
    }

    private void drawLink(Canvas c, float cx, float cy, float r, boolean broken) {
        c.save();
        c.rotate(-45, cx, cy);
        float lw = r * 0.62f, lh = r * 0.42f, gap = broken ? r * 0.30f : r * 0.06f;
        stroke.setStrokeWidth(r * 0.17f);
        stroke.setShader(fill.getShader());
        rf.set(cx - lw - gap, cy - lh / 2, cx + lw * 0.25f - gap, cy + lh / 2);
        c.drawRoundRect(rf, lh / 2, lh / 2, stroke);
        rf.set(cx - lw * 0.25f + gap, cy - lh / 2, cx + lw + gap, cy + lh / 2);
        c.drawRoundRect(rf, lh / 2, lh / 2, stroke);
        c.restore();
        stroke.setShader(null);
    }

    private void drawRadar(Canvas c, float cx, float cy, float r) {
        stroke.setStrokeWidth(r * 0.10f);
        stroke.setColor((color & 0x00FFFFFF) | 0x88000000);
        c.drawCircle(cx, cy, r * 0.92f, stroke);
        c.drawCircle(cx, cy, r * 0.55f, stroke);
        // sweep wedge
        fill.setShader(new RadialGradient(cx, cy, r, (color & 0x00FFFFFF) | 0xCC000000,
                (color & 0x00FFFFFF) | 0x22000000, Shader.TileMode.CLAMP));
        rf.set(cx - r * 0.92f, cy - r * 0.92f, cx + r * 0.92f, cy + r * 0.92f);
        c.drawArc(rf, -90, 70, true, fill);
        stroke.setColor(Color.WHITE);
        stroke.setStrokeWidth(r * 0.12f);
        c.drawLine(cx, cy, cx + (float) Math.cos(Math.toRadians(-20)) * r * 0.92f,
                cy + (float) Math.sin(Math.toRadians(-20)) * r * 0.92f, stroke);
        fill.setShader(null);
        fill.setColor(Color.WHITE);
        c.drawCircle(cx - r * 0.35f, cy + r * 0.30f, r * 0.11f, fill);
    }

    private void drawWarning(Canvas c, float cx, float cy, float r) {
        path.reset();
        path.moveTo(cx, cy - r * 0.92f);
        path.lineTo(cx + r * 0.98f, cy + r * 0.80f);
        path.lineTo(cx - r * 0.98f, cy + r * 0.80f);
        path.close();
        stroke.setStrokeWidth(r * 0.14f);
        c.drawPath(path, stroke);
        fill.setShader(null);
        fill.setColor(color);
        rf.set(cx - r * 0.08f, cy - r * 0.38f, cx + r * 0.08f, cy + r * 0.28f);
        c.drawRoundRect(rf, r * 0.08f, r * 0.08f, fill);
        c.drawCircle(cx, cy + r * 0.52f, r * 0.10f, fill);
    }
}
