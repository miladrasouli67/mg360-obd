package ir.obd.mg360;

import android.content.Context;
import android.view.View;
import android.view.ViewGroup;

import java.util.ArrayList;
import java.util.List;

/**
 * Places gauges at fixed positions of a 1024 x 424 design canvas, scaled uniformly to fit
 * and centred. Children added later are drawn on top (used by the overlapping "cluster" layout).
 */
public class DashboardLayout extends ViewGroup {

    public static final float DESIGN_W = 1024f;
    public static final float DESIGN_H = 424f;

    private static final class Slot {
        final View v;
        final float x, y, w, h; // design units (box)

        Slot(View v, float x, float y, float w, float h) {
            this.v = v;
            this.x = x;
            this.y = y;
            this.w = w;
            this.h = h;
        }
    }

    private final List<Slot> slots = new ArrayList<>();

    public DashboardLayout(Context ctx) {
        super(ctx);
        setClipChildren(false);
    }

    /** A round gauge whose dial has radius r (design units) and centre (cx, cy). */
    public void addGauge(View v, float cx, float cy, float r) {
        float side = 2 * r / 0.86f; // GaugeView: radius = side / 2 * 0.86
        addBox(v, cx - side / 2, cy - side / 2, side, side);
    }

    public void addBox(View v, float x, float y, float w, float h) {
        slots.add(new Slot(v, x, y, w, h));
        addView(v);
    }

    private float scale(int w, int h) {
        return Math.min(w / DESIGN_W, h / DESIGN_H);
    }

    @Override
    protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
        int w = MeasureSpec.getSize(widthMeasureSpec);
        int h = MeasureSpec.getSize(heightMeasureSpec);
        setMeasuredDimension(w, h);
        float s = scale(w, h);
        for (Slot sl : slots) {
            sl.v.measure(MeasureSpec.makeMeasureSpec(Math.round(sl.w * s), MeasureSpec.EXACTLY),
                    MeasureSpec.makeMeasureSpec(Math.round(sl.h * s), MeasureSpec.EXACTLY));
        }
    }

    @Override
    protected void onLayout(boolean changed, int l, int t, int r, int b) {
        int w = r - l, h = b - t;
        float s = scale(w, h);
        float ox = (w - DESIGN_W * s) / 2f, oy = (h - DESIGN_H * s) / 2f;
        for (Slot sl : slots) {
            int left = Math.round(ox + sl.x * s), top = Math.round(oy + sl.y * s);
            sl.v.layout(left, top, left + sl.v.getMeasuredWidth(), top + sl.v.getMeasuredHeight());
        }
    }
}
