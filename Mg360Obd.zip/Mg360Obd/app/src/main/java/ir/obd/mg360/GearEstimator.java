package ir.obd.mg360;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Locale;

/**
 * Works out the current gear from engine speed and road speed, without any car-specific data.
 *
 * In a given gear, rpm / speed is (almost) constant. While driving, the estimator collects that
 * ratio into a histogram; each gear shows up as a peak. Peaks are sorted from the highest ratio
 * (1st gear) to the lowest (top gear). The current gear is the peak closest to the current ratio.
 * Pure Java so it can be unit-tested; the histogram can be saved and restored as text.
 */
public class GearEstimator {

    private static final double MIN_RATIO = 5, MAX_RATIO = 250;   // rpm per km/h
    private static final double BIN = 0.02;                         // ~2 % per bin (log scale)
    private static final int BINS = (int) Math.ceil(Math.log(MAX_RATIO / MIN_RATIO) / BIN) + 1;
    private static final double MATCH = 0.08;                       // ±8 % to count as "in gear"
    private static final double MIN_SEP = 0.11;                     // gears are at least ~11 % apart
    private static final int MIN_PEAK = 20;                         // samples needed to trust a peak
    private static final int CAP = 30000;                           // keep counts bounded

    private final int[] hist = new int[BINS];
    private int maxGears;
    private double[] gears = new double[0];   // learned ratios, 1st gear first
    private double lastRatio = Double.NaN;
    private int samplesSinceUpdate = 0;
    private Integer lastGear = null;
    private int stableCount = 0;

    public GearEstimator(int maxGears) {
        this.maxGears = Math.max(2, Math.min(8, maxGears));
    }

    public void setMaxGears(int n) {
        maxGears = Math.max(2, Math.min(8, n));
        recompute();
    }

    public int learnedGears() {
        return gears.length;
    }

    public void reset() {
        java.util.Arrays.fill(hist, 0);
        gears = new double[0];
        lastGear = null;
    }

    private static int bin(double ratio) {
        return (int) Math.round(Math.log(ratio / MIN_RATIO) / BIN);
    }

    private static double ratioOf(int bin) {
        return MIN_RATIO * Math.exp(bin * BIN);
    }

    /**
     * Feed one reading. Returns the gear (1..n), or null when it cannot be told
     * (standing still, clutch pressed, changing gear, or not learned yet).
     */
    public Integer update(double rpm, double speedKmh) {
        if (Double.isNaN(rpm) || Double.isNaN(speedKmh) || speedKmh < 6 || rpm < 600) {
            lastRatio = Double.NaN;
            lastGear = null;
            stableCount = 0;
            return null;
        }
        double ratio = rpm / speedKmh;
        if (ratio < MIN_RATIO || ratio > MAX_RATIO) return null;

        // learn only from steady samples (ratio within 3 % of the previous one)
        if (!Double.isNaN(lastRatio) && Math.abs(Math.log(ratio / lastRatio)) < 0.03) {
            int b = bin(ratio);
            if (b >= 0 && b < BINS) {
                hist[b]++;
                if (hist[b] > CAP) for (int i = 0; i < BINS; i++) hist[i] /= 2;
            }
            if (++samplesSinceUpdate >= 10 || gears.length == 0) {
                samplesSinceUpdate = 0;
                recompute();
            }
        }
        lastRatio = ratio;

        Integer g = match(ratio);
        // require two consistent readings so the number does not flicker during a shift
        if (g != null && g.equals(lastGear)) stableCount++;
        else stableCount = 0;
        lastGear = g;
        return stableCount >= 1 ? g : null;
    }

    /** Gear for a ratio using the learned peaks, or null. */
    public Integer match(double ratio) {
        int best = -1;
        double bestD = MATCH;
        for (int i = 0; i < gears.length; i++) {
            double d = Math.abs(Math.log(ratio / gears[i]));
            if (d < bestD) {
                bestD = d;
                best = i;
            }
        }
        return best < 0 ? null : best + 1;
    }

    private void recompute() {
        // smooth over 3 bins
        double[] sm = new double[BINS];
        for (int i = 0; i < BINS; i++) {
            double s = hist[i] * 2.0;
            if (i > 0) s += hist[i - 1];
            if (i < BINS - 1) s += hist[i + 1];
            sm[i] = s / 4.0;
        }
        List<int[]> peaks = new ArrayList<>(); // {bin, strength}
        for (int i = 1; i < BINS - 1; i++) {
            if (sm[i] >= MIN_PEAK && sm[i] >= sm[i - 1] && sm[i] > sm[i + 1]) {
                peaks.add(new int[]{i, (int) sm[i]});
            }
        }
        // strongest first, drop peaks too close to a stronger one
        Collections.sort(peaks, (a, b) -> b[1] - a[1]);
        int sepBins = (int) Math.round(MIN_SEP / BIN);
        List<Integer> kept = new ArrayList<>();
        for (int[] p : peaks) {
            boolean ok = true;
            for (int k : kept) if (Math.abs(k - p[0]) < sepBins) ok = false;
            if (ok) kept.add(p[0]);
            if (kept.size() >= maxGears) break;
        }
        // 1st gear = highest rpm per km/h
        Collections.sort(kept, Collections.reverseOrder());
        double[] g = new double[kept.size()];
        for (int i = 0; i < g.length; i++) g[i] = ratioOf(kept.get(i));
        gears = g;
    }

    /** Learned ratios, for display in settings. */
    public String describe() {
        if (gears.length == 0) return "هنوز یاد نگرفته";
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < gears.length; i++) {
            if (i > 0) sb.append("   ");
            sb.append(i + 1).append(": ").append(String.format(Locale.US, "%.0f", gears[i]));
        }
        return sb.toString();
    }

    // -------- persistence --------

    public String save() {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < BINS; i++) {
            if (hist[i] == 0) continue;
            sb.append(i).append(':').append(hist[i]).append(',');
        }
        return sb.toString();
    }

    public void load(String s) {
        java.util.Arrays.fill(hist, 0);
        if (s != null) {
            for (String part : s.split(",")) {
                int c = part.indexOf(':');
                if (c <= 0) continue;
                try {
                    int b = Integer.parseInt(part.substring(0, c));
                    int n = Integer.parseInt(part.substring(c + 1));
                    if (b >= 0 && b < BINS) hist[b] = n;
                } catch (NumberFormatException ignored) {
                }
            }
        }
        recompute();
    }
}
