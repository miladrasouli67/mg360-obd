package ir.obd.mg360;

import android.content.Context;
import android.media.AudioAttributes;
import android.media.AudioFocusRequest;
import android.media.AudioFormat;
import android.media.AudioManager;
import android.media.AudioTrack;
import android.os.Build;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * Plays short synthesized alert sounds the polite way: it asks Android for temporary audio focus,
 * so the head unit lowers (ducks) or pauses the music only while the alert plays, and then
 * gives focus back so the music returns to normal.
 */
public class AlertPlayer {

    private static final int RATE = 44100;

    private final AudioManager am;
    private final ExecutorService exec = Executors.newSingleThreadExecutor();
    private final AudioAttributes attrs;

    public AlertPlayer(Context ctx) {
        am = (AudioManager) ctx.getSystemService(Context.AUDIO_SERVICE);
        // Same category as navigation voice prompts: head units duck music for these.
        attrs = new AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_ASSISTANCE_NAVIGATION_GUIDANCE)
                .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                .build();
    }

    /** Small, soft double "pip" — for the speed warning. Music is only lowered. */
    public void playSpeedBeep() {
        short[] pcm = concat(
                silence(250),
                tone(1320, 110, 0.45f),
                silence(70),
                tone(1320, 110, 0.45f),
                silence(150));
        play(pcm, false);
    }

    /** Urgent two-tone siren — for the coolant warning. Music is paused during it. */
    public void playDangerAlarm() {
        short[] one = concat(tone(960, 230, 0.9f), tone(640, 230, 0.9f));
        short[] pcm = concat(silence(300), one, one, one, silence(120), one, one, silence(200));
        play(pcm, true);
    }

    private void play(short[] pcm, boolean pauseMusic) {
        exec.execute(() -> {
            Object focus = requestFocus(pauseMusic);
            AudioTrack track = null;
            try {
                track = new AudioTrack.Builder()
                        .setAudioAttributes(attrs)
                        .setAudioFormat(new AudioFormat.Builder()
                                .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                                .setSampleRate(RATE)
                                .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                                .build())
                        .setTransferMode(AudioTrack.MODE_STATIC)
                        .setBufferSizeInBytes(pcm.length * 2)
                        .build();
                track.write(pcm, 0, pcm.length);
                track.play();
                Thread.sleep(pcm.length * 1000L / RATE + 150);
            } catch (Exception ignored) {
                // never let an alert crash the app
            } finally {
                if (track != null) {
                    try {
                        track.stop();
                    } catch (Exception ignored) {
                    }
                    track.release();
                }
                abandonFocus(focus);
            }
        });
    }

    @SuppressWarnings("deprecation")
    private Object requestFocus(boolean pauseMusic) {
        if (am == null) return null;
        int type = pauseMusic ? AudioManager.AUDIOFOCUS_GAIN_TRANSIENT
                : AudioManager.AUDIOFOCUS_GAIN_TRANSIENT_MAY_DUCK;
        try {
            if (Build.VERSION.SDK_INT >= 26) {
                AudioFocusRequest req = new AudioFocusRequest.Builder(type)
                        .setAudioAttributes(attrs)
                        .setOnAudioFocusChangeListener(f -> { })
                        .build();
                am.requestAudioFocus(req);
                return req;
            } else {
                AudioManager.OnAudioFocusChangeListener l = f -> { };
                am.requestAudioFocus(l, AudioManager.STREAM_MUSIC, type);
                return l;
            }
        } catch (Exception e) {
            return null;
        }
    }

    @SuppressWarnings("deprecation")
    private void abandonFocus(Object focus) {
        if (am == null || focus == null) return;
        try {
            if (Build.VERSION.SDK_INT >= 26 && focus instanceof AudioFocusRequest) {
                am.abandonAudioFocusRequest((AudioFocusRequest) focus);
            } else if (focus instanceof AudioManager.OnAudioFocusChangeListener) {
                am.abandonAudioFocus((AudioManager.OnAudioFocusChangeListener) focus);
            }
        } catch (Exception ignored) {
        }
    }

    public void release() {
        exec.shutdownNow();
    }

    // ------------------------------------------------------------ synthesis

    private static short[] tone(double freq, int ms, float volume) {
        int n = RATE * ms / 1000;
        short[] out = new short[n];
        int fade = Math.min(n / 4, RATE * 8 / 1000); // 8 ms fade in/out, no clicks
        for (int i = 0; i < n; i++) {
            double env = 1.0;
            if (i < fade) env = i / (double) fade;
            else if (i > n - fade) env = (n - i) / (double) fade;
            // a touch of the 2nd harmonic makes small speakers sound clearer
            double s = Math.sin(2 * Math.PI * freq * i / RATE) * 0.85
                    + Math.sin(4 * Math.PI * freq * i / RATE) * 0.15;
            out[i] = (short) (s * env * volume * Short.MAX_VALUE);
        }
        return out;
    }

    private static short[] silence(int ms) {
        return new short[RATE * ms / 1000];
    }

    private static short[] concat(short[]... parts) {
        int len = 0;
        for (short[] p : parts) len += p.length;
        short[] out = new short[len];
        int pos = 0;
        for (short[] p : parts) {
            System.arraycopy(p, 0, out, pos, p.length);
            pos += p.length;
        }
        return out;
    }
}
