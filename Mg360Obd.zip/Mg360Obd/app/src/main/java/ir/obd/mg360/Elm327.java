package ir.obd.mg360;

import android.annotation.SuppressLint;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothSocket;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.lang.reflect.Method;
import java.nio.charset.StandardCharsets;
import java.util.Locale;
import java.util.UUID;

/**
 * Minimal ELM327 client over Bluetooth Classic (SPP). Read-only diagnostics:
 * this class never writes to ECU memory.
 * All methods block and must be called from a background thread.
 */
public class Elm327 {

    private static final UUID SPP_UUID = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB");

    private BluetoothSocket socket;
    private InputStream in;
    private OutputStream out;
    private boolean can = true;

    public boolean isCan() {
        return can;
    }

    @SuppressLint("MissingPermission")
    public void connect(BluetoothDevice device) throws IOException {
        IOException first;
        try {
            socket = device.createRfcommSocketToServiceRecord(SPP_UUID);
            socket.connect();
            openStreams();
            return;
        } catch (IOException e) {
            first = e;
            closeQuietly();
        }
        // Fallback 1: insecure socket (some clones)
        try {
            socket = device.createInsecureRfcommSocketToServiceRecord(SPP_UUID);
            socket.connect();
            openStreams();
            return;
        } catch (IOException e) {
            closeQuietly();
        }
        // Fallback 2: hidden API, channel 1 (needed by many cheap ELM327 clones)
        try {
            Method m = device.getClass().getMethod("createRfcommSocket", int.class);
            socket = (BluetoothSocket) m.invoke(device, 1);
            socket.connect();
            openStreams();
        } catch (Exception e) {
            closeQuietly();
            throw first;
        }
    }

    private void openStreams() throws IOException {
        in = socket.getInputStream();
        out = socket.getOutputStream();
    }

    /**
     * Initialises the adapter and the connection to the car.
     * @return the answer to "0100" (useful for showing errors)
     */
    public String init() throws IOException {
        send("ATZ", 4000);       // reset
        send("ATE0", 1500);      // echo off
        send("ATL0", 1500);      // linefeeds off
        send("ATS0", 1500);      // spaces off
        send("ATH0", 1500);      // headers off
        send("ATAT1", 1500);     // adaptive timing
        send("ATSP0", 1500);     // automatic protocol
        String r = send("0100", 15000); // triggers protocol search
        String dp = send("ATDPN", 1500);
        can = ObdParser.isCanProtocol(dp);
        return r;
    }

    public String protocolName() throws IOException {
        return ObdParser.lines(send("ATDP", 1500)).toString();
    }

    /** Sends one command and returns everything up to the '>' prompt. */
    public synchronized String send(String cmd, long timeoutMs) throws IOException {
        if (in == null || out == null) throw new IOException("not connected");
        // discard leftovers
        while (in.available() > 0) {
            if (in.read() < 0) throw new IOException("stream closed");
        }
        out.write((cmd + "\r").getBytes(StandardCharsets.US_ASCII));
        out.flush();

        StringBuilder sb = new StringBuilder();
        long deadline = System.currentTimeMillis() + timeoutMs;
        while (System.currentTimeMillis() < deadline) {
            if (in.available() > 0) {
                int c = in.read();
                if (c < 0) throw new IOException("stream closed");
                if (c == '>') return sb.toString();
                if (c != 0) sb.append((char) c);
            } else {
                try {
                    Thread.sleep(5);
                } catch (InterruptedException e) {
                    Thread.currentThread().interrupt();
                    throw new IOException("interrupted");
                }
            }
        }
        return sb.toString(); // timeout: return what we have
    }

    /** Mode 01 request; returns data bytes or null. */
    public int[] readPid(int pid) throws IOException {
        String r = send(String.format(Locale.US, "01%02X", pid), 3000);
        return ObdParser.pidData(r, 1, pid);
    }

    public void close() {
        closeQuietly();
    }

    private void closeQuietly() {
        try {
            if (socket != null) socket.close();
        } catch (IOException ignored) {
        }
        socket = null;
        in = null;
        out = null;
    }
}
