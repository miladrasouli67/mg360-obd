package ir.obd.mg360;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.Locale;
import java.util.Map;

/**
 * Minimal ELM327 client that works over any {@link Transports.Transport} (Bluetooth, Wi-Fi, USB).
 * Read-only diagnostics: never writes to ECU memory.
 * All methods block and must be called from a background thread.
 */
public class Elm327 {

    private volatile Transports.Transport t;
    private boolean can = true;
    private final byte[] buf = new byte[1024];

    public synchronized void attach(Transports.Transport transport) {
        close();
        t = transport;
    }

    public boolean isCan() {
        return can;
    }

    /** True if the adapter answers to ATZ/ATI (used to probe USB baud rates). */
    public boolean probe() {
        try {
            String r = send("ATI", 1200);
            return r.toUpperCase().contains("ELM") || r.contains("OK") || r.toUpperCase().contains("V1");
        } catch (IOException e) {
            return false;
        }
    }

    /**
     * Initialises the adapter and the connection to the car.
     * @return the answer to "0100" (useful for showing errors)
     */
    public String init() throws IOException {
        send("ATZ", 4000);       // reset
        send("ATE0", 1500);      // echo off
        send("ATL0", 1500);      // linefeeds off
        send("ATS0", 1500);      // spaces off
        send("ATH0", 1500);      // headers off
        send("ATAT1", 1500);     // adaptive timing
        send("ATSP0", 1500);     // automatic protocol
        String r = send("0100", 15000); // triggers protocol search
        String dp = send("ATDPN", 1500);
        can = ObdParser.isCanProtocol(dp);
        return r;
    }

    /** Sends one command and returns everything up to the '>' prompt. */
    public synchronized String send(String cmd, long timeoutMs) throws IOException {
        Transports.Transport tr = t;
        if (tr == null) throw new IOException("not connected");
        // discard leftovers
        tr.read(buf, 5);
        tr.write((cmd + "\r").getBytes(StandardCharsets.US_ASCII));

        StringBuilder sb = new StringBuilder();
        long deadline = System.currentTimeMillis() + timeoutMs;
        while (true) {
            long left = deadline - System.currentTimeMillis();
            if (left <= 0) return sb.toString(); // timeout: return what we have
            int n = tr.read(buf, (int) Math.min(left, 100));
            for (int i = 0; i < n; i++) {
                char ch = (char) (buf[i] & 0xFF);
                if (ch == '>') return sb.toString();
                if (ch != 0) sb.append(ch);
            }
        }
    }

    /** Mode 01 request; returns data bytes or null. */
    public int[] readPid(int pid) throws IOException {
        String r = send(String.format(Locale.US, "01%02X", pid), 3000);
        return ObdParser.pidData(r, 1, pid);
    }

    /** Requests up to 6 PIDs in one message (CAN only) and returns pid -> bytes. */
    public Map<Integer, int[]> readPids(int... pids) throws IOException {
        StringBuilder cmd = new StringBuilder("01");
        for (int p : pids) cmd.append(String.format(Locale.US, "%02X", p));
        return ObdParser.parseMode01(send(cmd.toString(), 3000));
    }

    public void close() {
        Transports.Transport tr = t;
        t = null;
        if (tr != null) tr.close();
    }
}
