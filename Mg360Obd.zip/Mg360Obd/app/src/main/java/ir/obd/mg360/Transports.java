package ir.obd.mg360;

import android.annotation.SuppressLint;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothSocket;
import android.hardware.usb.UsbDeviceConnection;
import android.hardware.usb.UsbManager;
import android.net.ConnectivityManager;
import android.net.Network;
import android.net.NetworkCapabilities;

import com.hoho.android.usbserial.driver.UsbSerialDriver;
import com.hoho.android.usbserial.driver.UsbSerialPort;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.lang.reflect.Method;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.net.SocketTimeoutException;
import java.util.UUID;

/** The three ways of talking to an ELM327: Bluetooth, Wi-Fi (TCP) and USB serial. */
public final class Transports {

    private Transports() {}

    /** A byte pipe to the adapter. */
    public interface Transport {
        void write(byte[] data) throws IOException;

        /** Reads what is available, waiting at most timeoutMs. Returns 0 on timeout. */
        int read(byte[] buf, int timeoutMs) throws IOException;

        void close();
    }

    // ------------------------------------------------------------------ Bluetooth

    public static class Bluetooth implements Transport {
        private static final UUID SPP = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB");
        private BluetoothSocket socket;
        private InputStream in;
        private OutputStream out;

        @SuppressLint("MissingPermission")
        public Bluetooth(BluetoothDevice device) throws IOException {
            IOException first;
            try {
                socket = device.createRfcommSocketToServiceRecord(SPP);
                socket.connect();
                open();
                return;
            } catch (IOException e) {
                first = e;
                close();
            }
            try {
                socket = device.createInsecureRfcommSocketToServiceRecord(SPP);
                socket.connect();
                open();
                return;
            } catch (IOException e) {
                close();
            }
            try {
                // hidden API, channel 1 — needed by many cheap ELM327 clones
                Method m = device.getClass().getMethod("createRfcommSocket", int.class);
                socket = (BluetoothSocket) m.invoke(device, 1);
                socket.connect();
                open();
            } catch (Exception e) {
                close();
                throw first;
            }
        }

        private void open() throws IOException {
            in = socket.getInputStream();
            out = socket.getOutputStream();
        }

        @Override
        public void write(byte[] data) throws IOException {
            if (out == null) throw new IOException("closed");
            out.write(data);
            out.flush();
        }

        @Override
        public int read(byte[] buf, int timeoutMs) throws IOException {
            if (in == null) throw new IOException("closed");
            long end = System.currentTimeMillis() + timeoutMs;
            while (true) {
                int avail = in.available();
                if (avail > 0) {
                    int n = in.read(buf, 0, Math.min(avail, buf.length));
                    if (n < 0) throw new IOException("stream closed");
                    return n;
                }
                if (System.currentTimeMillis() >= end) return 0;
                sleep(4);
            }
        }

        @Override
        public void close() {
            try {
                if (socket != null) socket.close();
            } catch (IOException ignored) {
            }
            socket = null;
            in = null;
            out = null;
        }
    }

    // ----------------------------------------------------------------------- Wi-Fi

    public static class Wifi implements Transport {
        private Socket socket;
        private InputStream in;
        private OutputStream out;

        /** Connects over the Wi-Fi network even if mobile data is the default route. */
        public Wifi(ConnectivityManager cm, String host, int port) throws IOException {
            Network wifi = null;
            if (cm != null) {
                try {
                    for (Network n : cm.getAllNetworks()) {
                        NetworkCapabilities caps = cm.getNetworkCapabilities(n);
                        if (caps != null && caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI)) {
                            wifi = n;
                            break;
                        }
                    }
                } catch (SecurityException ignored) {
                }
            }
            socket = wifi != null ? wifi.getSocketFactory().createSocket() : new Socket();
            try {
                socket.setTcpNoDelay(true);
                socket.connect(new InetSocketAddress(host, port), 6000);
                in = socket.getInputStream();
                out = socket.getOutputStream();
            } catch (IOException e) {
                close();
                throw new IOException("به " + host + ":" + port + " وصل نشد. گوشی به وای‌فای OBD وصل است؟");
            }
        }

        @Override
        public void write(byte[] data) throws IOException {
            if (out == null) throw new IOException("closed");
            out.write(data);
            out.flush();
        }

        @Override
        public int read(byte[] buf, int timeoutMs) throws IOException {
            if (in == null) throw new IOException("closed");
            socket.setSoTimeout(Math.max(1, timeoutMs));
            try {
                int n = in.read(buf);
                if (n < 0) throw new IOException("stream closed");
                return n;
            } catch (SocketTimeoutException e) {
                return 0;
            }
        }

        @Override
        public void close() {
            try {
                if (socket != null) socket.close();
            } catch (IOException ignored) {
            }
            socket = null;
            in = null;
            out = null;
        }
    }

    // ------------------------------------------------------------------------- USB

    public static class Usb implements Transport {
        private UsbSerialPort port;

        public Usb(UsbManager um, UsbSerialDriver driver, int baud) throws IOException {
            UsbDeviceConnection conn = um.openDevice(driver.getDevice());
            if (conn == null) throw new IOException("اجازه‌ی USB داده نشد");
            port = driver.getPorts().get(0);
            try {
                port.open(conn);
                port.setParameters(baud, 8, UsbSerialPort.STOPBITS_1, UsbSerialPort.PARITY_NONE);
                try {
                    port.setDTR(true);
                    port.setRTS(true);
                } catch (Exception ignored) {
                    // not supported by every chip
                }
            } catch (IOException e) {
                close();
                throw e;
            }
        }

        @Override
        public void write(byte[] data) throws IOException {
            if (port == null) throw new IOException("closed");
            port.write(data, 1000);
        }

        @Override
        public int read(byte[] buf, int timeoutMs) throws IOException {
            if (port == null) throw new IOException("closed");
            // USB buffers must be at least the endpoint packet size
            return port.read(buf, Math.max(1, timeoutMs));
        }

        @Override
        public void close() {
            try {
                if (port != null) port.close();
            } catch (IOException ignored) {
            }
            port = null;
        }
    }

    static void sleep(long ms) throws IOException {
        try {
            Thread.sleep(ms);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            throw new IOException("interrupted");
        }
    }
}
