package ir.obd.mg360;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * Pure-Java helpers for parsing ELM327 responses (no Android dependencies, so it can be unit-tested).
 */
public final class ObdParser {

    private ObdParser() {}

    /** Removes prompt, spaces, "SEARCHING..." and blank lines; returns upper-case lines. */
    public static List<String> lines(String raw) {
        List<String> out = new ArrayList<>();
        if (raw == null) return out;
        String s = raw.replace(">", "").replace("\n", "\r").toUpperCase();
        for (String line : s.split("\r")) {
            String t = line.replace(" ", "").replace("\t", "").trim();
            if (t.isEmpty()) continue;
            if (t.startsWith("SEARCHING")) continue;
            if (t.startsWith("BUSINIT")) {
                // "BUS INIT: ...OK" may share a line with data on some adapters
                int idx = t.indexOf("OK");
                if (idx < 0) continue;
                t = t.substring(idx + 2);
                if (t.isEmpty()) continue;
            }
            out.add(t);
        }
        return out;
    }

    /** True if the adapter returned an error instead of data. */
    public static boolean isError(String raw) {
        if (raw == null) return true;
        String s = raw.toUpperCase().replace(" ", "");
        return s.contains("NODATA") || s.contains("UNABLETOCONNECT") || s.contains("ERROR")
                || s.contains("STOPPED") || s.contains("?") || s.trim().replace(">", "").isEmpty();
    }

    private static boolean isHex(String s) {
        if (s.isEmpty() || (s.length() % 2) != 0) return false;
        for (int i = 0; i < s.length(); i++) {
            if (Character.digit(s.charAt(i), 16) < 0) return false;
        }
        return true;
    }

    private static int[] toBytes(String hex) {
        int[] b = new int[hex.length() / 2];
        for (int i = 0; i < b.length; i++) {
            b[i] = Integer.parseInt(hex.substring(i * 2, i * 2 + 2), 16);
        }
        return b;
    }

    /**
     * Returns the data bytes after the "4x PP" header of a mode-01 style answer,
     * e.g. for request 0105 and answer "41057B" returns {0x7B}. Returns null if not found.
     */
    public static int[] pidData(String raw, int mode, int pid) {
        String header = String.format(Locale.US, "%02X%02X", 0x40 + mode, pid);
        for (String line : lines(raw)) {
            int idx = line.indexOf(header);
            if (idx < 0 || (idx % 2) != 0) continue;
            String rest = line.substring(idx + header.length());
            // Trim to whole bytes of valid hex
            StringBuilder sb = new StringBuilder();
            for (int i = 0; i + 1 < rest.length(); i += 2) {
                String b = rest.substring(i, i + 2);
                if (!isHex(b)) break;
                sb.append(b);
            }
            if (sb.length() == 0) continue;
            return toBytes(sb.toString());
        }
        return null;
    }

    /** True if the protocol number returned by ATDPN is a CAN protocol (6..C). */
    public static boolean isCanProtocol(String atdpnRaw) {
        List<String> l = lines(atdpnRaw);
        if (l.isEmpty()) return true; // modern cars: assume CAN
        String p = l.get(0);
        if (p.length() == 2 && p.charAt(0) == 'A') p = p.substring(1);
        if (p.isEmpty()) return true;
        char c = p.charAt(0);
        return "6789ABC".indexOf(c) >= 0;
    }

    /** Converts two raw DTC bytes into a code such as P0133. */
    public static String decodeDtc(int b1, int b2) {
        char letter = "PCBU".charAt((b1 >> 6) & 0x3);
        int d1 = (b1 >> 4) & 0x3;
        return String.format(Locale.US, "%c%d%X%X%X", letter, d1, b1 & 0xF, (b2 >> 4) & 0xF, b2 & 0xF);
    }

    /**
     * Parses the answer to mode 03 (stored), 07 (pending) or 0A (permanent).
     * Handles single-frame, multi-frame CAN ("0:" "1:" prefixed lines) and multiple ECUs.
     */
    public static List<String> parseDtcs(String raw, int mode, boolean isCan) {
        List<String> codes = new ArrayList<>();
        if (isError(raw) && !raw.toUpperCase().replace(" ", "").contains(String.format(Locale.US, "%02X", 0x40 + mode))) {
            return codes;
        }
        String respHeader = String.format(Locale.US, "%02X", 0x40 + mode);

        // Build messages: a message begins at a line with no frame index or index 0.
        List<StringBuilder> messages = new ArrayList<>();
        StringBuilder current = null;
        for (String line : lines(raw)) {
            String data = line;
            int frameIndex = -1;
            if (line.length() >= 2 && line.charAt(1) == ':' && Character.digit(line.charAt(0), 16) >= 0) {
                frameIndex = Character.digit(line.charAt(0), 16);
                data = line.substring(2);
            } else if (line.length() == 3 && isHexChars(line)) {
                continue; // multi-frame total length line, e.g. "00A"
            }
            if (!isHex(data)) continue;
            if (frameIndex <= 0 || current == null) {
                current = new StringBuilder();
                messages.add(current);
            }
            current.append(data);
        }

        for (StringBuilder m : messages) {
            String s = m.toString();
            if (!s.startsWith(respHeader)) continue;
            int[] b = toBytes(s);
            int start = 1;
            int max = Integer.MAX_VALUE;
            if (isCan) {
                if (b.length < 2) continue;
                max = b[1];
                start = 2;
            }
            int count = 0;
            for (int i = start; i + 1 < b.length && count < max; i += 2) {
                if (b[i] == 0 && b[i + 1] == 0) {
                    if (isCan) count++;
                    continue;
                }
                String code = decodeDtc(b[i], b[i + 1]);
                if (!codes.contains(code)) codes.add(code);
                count++;
            }
        }
        return codes;
    }

    private static boolean isHexChars(String s) {
        for (int i = 0; i < s.length(); i++) {
            if (Character.digit(s.charAt(i), 16) < 0) return false;
        }
        return true;
    }

    /** Battery voltage from "ATRV" answer like "12.6V". Returns NaN if not parsable. */
    public static double parseVoltage(String raw) {
        for (String line : lines(raw)) {
            String t = line.replace("V", "");
            try {
                return Double.parseDouble(t);
            } catch (NumberFormatException ignored) {
            }
        }
        return Double.NaN;
    }
}
