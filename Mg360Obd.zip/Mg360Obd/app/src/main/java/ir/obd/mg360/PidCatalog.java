package ir.obd.mg360;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.TreeSet;

/**
 * Standard OBD-II mode 01 PIDs this app understands: Persian name, unit, byte length and formula.
 * Pure Java (unit-testable).
 */
public final class PidCatalog {

    private PidCatalog() {}

    public interface Formula {
        double calc(int[] d);
    }

    public static final class Pid {
        public final int pid;
        public final String name;
        public final String unit;
        public final int length;
        public final int decimals;
        /** For drawing a bar under the value; NaN = no bar. */
        public final double barMax;
        private final Formula f;

        Pid(int pid, String name, String unit, int length, int decimals, double barMax, Formula f) {
            this.pid = pid;
            this.name = name;
            this.unit = unit;
            this.length = length;
            this.decimals = decimals;
            this.barMax = barMax;
            this.f = f;
        }

        public double value(int[] d) {
            if (d == null || d.length < length) return Double.NaN;
            return f.calc(d);
        }

        public String format(double v) {
            if (Double.isNaN(v)) return "--";
            if (decimals == 0) return String.valueOf(Math.round(v));
            return String.format(Locale.US, "%." + decimals + "f", v);
        }
    }

    private static final Map<Integer, Pid> ALL = new LinkedHashMap<>();
    private static final double NB = Double.NaN;

    private static void add(int pid, String name, String unit, int len, int dec, double barMax, Formula f) {
        ALL.put(pid, new Pid(pid, name, unit, len, dec, barMax, f));
    }

    private static int ab(int[] d) {
        return d[0] * 256 + d[1];
    }

    static {
        add(0x04, "بار موتور", "%", 1, 0, 100, d -> d[0] * 100.0 / 255);
        add(0x05, "دمای آب", "°C", 1, 0, NB, d -> d[0] - 40);
        add(0x06, "تریم سوخت کوتاه‌مدت ۱", "%", 1, 1, NB, d -> (d[0] - 128) * 100.0 / 128);
        add(0x07, "تریم سوخت بلندمدت ۱", "%", 1, 1, NB, d -> (d[0] - 128) * 100.0 / 128);
        add(0x08, "تریم سوخت کوتاه‌مدت ۲", "%", 1, 1, NB, d -> (d[0] - 128) * 100.0 / 128);
        add(0x09, "تریم سوخت بلندمدت ۲", "%", 1, 1, NB, d -> (d[0] - 128) * 100.0 / 128);
        add(0x0A, "فشار سوخت", "kPa", 1, 0, NB, d -> d[0] * 3);
        add(0x0B, "فشار منیفولد (MAP)", "kPa", 1, 0, NB, d -> d[0]);
        add(0x0C, "دور موتور", "rpm", 2, 0, 7000, d -> ab(d) / 4.0);
        add(0x0D, "سرعت", "km/h", 1, 0, NB, d -> d[0]);
        add(0x0E, "آوانس جرقه", "°", 1, 1, NB, d -> d[0] / 2.0 - 64);
        add(0x0F, "دمای هوای ورودی", "°C", 1, 0, NB, d -> d[0] - 40);
        add(0x10, "دبی هوا (MAF)", "g/s", 2, 1, NB, d -> ab(d) / 100.0);
        add(0x11, "دریچه گاز", "%", 1, 0, 100, d -> d[0] * 100.0 / 255);
        add(0x1F, "زمان از استارت", "s", 2, 0, NB, PidCatalog::ab);
        add(0x21, "مسافت با چراغ چک روشن", "km", 2, 0, NB, PidCatalog::ab);
        add(0x22, "فشار ریل سوخت", "kPa", 2, 0, NB, d -> ab(d) * 0.079);
        add(0x23, "فشار ریل سوخت (گیج)", "bar", 2, 1, NB, d -> ab(d) * 10 / 100.0);
        for (int i = 0; i < 8; i++) {
            add(0x24 + i, "لامبدا سنسور اکسیژن " + (i + 1), "λ", 4, 3, NB, d -> ab(d) * 2.0 / 65536);
        }
        add(0x2C, "فرمان EGR", "%", 1, 0, 100, d -> d[0] * 100.0 / 255);
        add(0x2E, "فرمان پرج کنیستر", "%", 1, 0, 100, d -> d[0] * 100.0 / 255);
        add(0x2F, "سطح بنزین", "%", 1, 0, 100, d -> d[0] * 100.0 / 255);
        add(0x30, "تعداد گرم شدن از پاک شدن کدها", "", 1, 0, NB, d -> d[0]);
        add(0x31, "مسافت از پاک شدن کدها", "km", 2, 0, NB, PidCatalog::ab);
        add(0x33, "فشار هوای محیط", "kPa", 1, 0, NB, d -> d[0]);
        for (int i = 0; i < 8; i++) {
            add(0x34 + i, "لامبدا (پهن‌باند) سنسور " + (i + 1), "λ", 4, 3, NB, d -> ab(d) * 2.0 / 65536);
        }
        add(0x3C, "دمای کاتالیست ۱", "°C", 2, 0, NB, d -> ab(d) / 10.0 - 40);
        add(0x3D, "دمای کاتالیست ۲", "°C", 2, 0, NB, d -> ab(d) / 10.0 - 40);
        add(0x3E, "دمای کاتالیست ۳", "°C", 2, 0, NB, d -> ab(d) / 10.0 - 40);
        add(0x3F, "دمای کاتالیست ۴", "°C", 2, 0, NB, d -> ab(d) / 10.0 - 40);
        add(0x42, "ولتاژ تغذیه‌ی ECU", "V", 2, 2, NB, d -> ab(d) / 1000.0);
        add(0x43, "بار مطلق موتور", "%", 2, 0, NB, d -> ab(d) * 100.0 / 255);
        add(0x44, "لامبدای فرمان‌داده‌شده", "λ", 2, 3, NB, d -> ab(d) * 2.0 / 65536);
        add(0x45, "دریچه گاز نسبی", "%", 1, 0, 100, d -> d[0] * 100.0 / 255);
        add(0x46, "دمای هوای بیرون", "°C", 1, 0, NB, d -> d[0] - 40);
        add(0x47, "دریچه گاز مطلق B", "%", 1, 0, 100, d -> d[0] * 100.0 / 255);
        add(0x49, "پدال گاز D", "%", 1, 0, 100, d -> d[0] * 100.0 / 255);
        add(0x4A, "پدال گاز E", "%", 1, 0, 100, d -> d[0] * 100.0 / 255);
        add(0x4C, "فرمان دریچه گاز", "%", 1, 0, 100, d -> d[0] * 100.0 / 255);
        add(0x4D, "زمان با چراغ چک روشن", "min", 2, 0, NB, PidCatalog::ab);
        add(0x4E, "زمان از پاک شدن کدها", "min", 2, 0, NB, PidCatalog::ab);
        add(0x52, "درصد اتانول", "%", 1, 0, NB, d -> d[0] * 100.0 / 255);
        add(0x5A, "پدال گاز نسبی", "%", 1, 0, 100, d -> d[0] * 100.0 / 255);
        add(0x5C, "دمای روغن موتور", "°C", 1, 0, NB, d -> d[0] - 40);
        add(0x5D, "زمان پاشش سوخت", "°", 2, 1, NB, d -> ab(d) / 128.0 - 210);
        add(0x5E, "مصرف لحظه‌ای سوخت", "L/h", 2, 1, NB, d -> ab(d) / 20.0);
        add(0x61, "گشتاور درخواستی راننده", "%", 1, 0, NB, d -> d[0] - 125);
        add(0x62, "گشتاور واقعی موتور", "%", 1, 0, NB, d -> d[0] - 125);
        add(0x63, "گشتاور مرجع موتور", "Nm", 2, 0, NB, PidCatalog::ab);
        // ---- newer standard PIDs (formulas from SAE J1979 tables) ----
        add(0x67, "دمای آب (سنسور ۲)", "°C", 3, 0, NB, d -> (d[0] & 0x02) != 0 ? d[2] - 40 : Double.NaN);
        add(0x68, "دمای هوای ورودی (سنسور ۲)", "°C", 3, 0, NB, d -> (d[0] & 0x02) != 0 ? d[2] - 40 : Double.NaN);
        add(0x7F, "کل کارکرد موتور", "ساعت", 13, 1, NB,
                d -> ((long) d[1] << 24 | (long) d[2] << 16 | (long) d[3] << 8 | d[4]) / 3600.0);
        add(0x8E, "گشتاور اصطکاک موتور", "%", 1, 0, NB, d -> d[0] - 125);
        // gear reported by the car itself: byte B high nibble (0 = neutral); bytes C,D = gearbox ratio
        add(0xA4, "دنده (از خود ماشین)", "", 4, 0, NB, d -> (d[0] & 0x02) != 0 ? (d[1] >> 4) : Double.NaN);
        add(0xA6, "کیلومترشمار ماشین", "km", 4, 0, NB,
                d -> ((long) d[0] << 24 | (long) d[1] << 16 | (long) d[2] << 8 | d[3]) / 10.0);
        add(0xA9, "کلید خاموش کردن ABS (۱ = زده شده)", "", 4, 0, NB, d -> (d[0] & 0x01) != 0 ? (d[1] & 0x01) : Double.NaN);
    }

    public static Pid get(int pid) {
        return ALL.get(pid);
    }

    public static List<Pid> all() {
        return new ArrayList<>(ALL.values());
    }

    /** Gearbox ratio from a PID A4 answer, e.g. 3.454; NaN if not reported. */
    public static double gearRatio(int[] d) {
        if (d == null || d.length < 4 || (d[0] & 0x02) == 0) return Double.NaN;
        double r = (d[2] * 256 + d[3]) / 1000.0;
        return r > 0.2 && r < 8 ? r : Double.NaN;
    }

    /** Data length of a mode-01 PID, or -1 if unknown. */
    public static int length(int pid) {
        if (pid == 0x00 || pid == 0x20 || pid == 0x40 || pid == 0x60 || pid == 0x80 || pid == 0xA0 || pid == 0xC0) {
            return 4;
        }
        Pid p = ALL.get(pid);
        return p == null ? -1 : p.length;
    }

    /**
     * Decodes a "supported PIDs" bitmap (answer to 0100/0120/0140...) into PID numbers.
     * @param base 0x00, 0x20, 0x40...
     */
    public static Set<Integer> decodeSupported(int base, int[] d) {
        Set<Integer> out = new TreeSet<>();
        if (d == null || d.length < 4) return out;
        for (int i = 0; i < 32; i++) {
            int b = d[i / 8];
            if ((b & (0x80 >> (i % 8))) != 0) out.add(base + i + 1);
        }
        return out;
    }
}
