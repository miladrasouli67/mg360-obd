package ir.obd.mg360;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.AlertDialog;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothManager;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Typeface;
import android.media.AudioManager;
import android.media.ToneGenerator;
import android.os.Build;
import android.os.Bundle;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.text.InputType;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.GridLayout;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.concurrent.LinkedBlockingQueue;

public class MainActivity extends Activity {

    private static final int REQ_BT = 1;
    private static final String PREFS = "settings";
    private static final String KEY_ALARM = "coolant_alarm";
    private static final String KEY_LAST_DEVICE = "last_device";

    // UI
    private TextView statusText, coolantText, iatText, boostText, rpmText, speedText,
            loadText, throttleText, voltText, dtcText;
    private EditText alarmEdit;
    private Button connectBtn, readDtcBtn, clearDtcBtn;

    // State
    private final Elm327 elm = new Elm327();
    private final LinkedBlockingQueue<Runnable> jobs = new LinkedBlockingQueue<>();
    private volatile boolean running = false;
    private Thread worker;
    private int alarmTemp = 105;
    private int baroKpa = 101;
    private long lastAlarmAt = 0;
    private ToneGenerator tone;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        alarmTemp = getSharedPreferences(PREFS, MODE_PRIVATE).getInt(KEY_ALARM, 105);
        buildUi();
        setConnectedUi(false);
        try {
            tone = new ToneGenerator(AudioManager.STREAM_ALARM, 100);
        } catch (RuntimeException ignored) {
            tone = null;
        }
    }

    // ---------------------------------------------------------------- UI

    private void buildUi() {
        int pad = dp(16);
        ScrollView scroll = new ScrollView(this);
        scroll.setBackgroundColor(Color.parseColor("#101418"));
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(pad, pad, pad, pad);
        root.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        scroll.addView(root);

        TextView title = label("MG360 Turbo — OBD", 22, Color.WHITE);
        title.setTypeface(Typeface.DEFAULT_BOLD);
        root.addView(title);

        statusText = label("وصل نیست", 14, Color.parseColor("#9AA4AE"));
        statusText.setPadding(0, dp(4), 0, dp(12));
        root.addView(statusText);

        connectBtn = button("اتصال به OBD");
        connectBtn.setOnClickListener(v -> {
            if (running) disconnect();
            else startConnectFlow();
        });
        root.addView(connectBtn, fullWidth());

        // Big coolant temperature
        TextView coolantLabel = label("دمای آب موتور", 14, Color.parseColor("#9AA4AE"));
        coolantLabel.setPadding(0, dp(16), 0, 0);
        root.addView(coolantLabel);
        coolantText = label("—", 56, Color.WHITE);
        coolantText.setTypeface(Typeface.DEFAULT_BOLD);
        root.addView(coolantText);

        // Grid of other values
        GridLayout grid = new GridLayout(this);
        grid.setColumnCount(2);
        grid.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        iatText = addTile(grid, "دمای هوای ورودی");
        boostText = addTile(grid, "فشار توربو (bar)");
        rpmText = addTile(grid, "دور موتور");
        speedText = addTile(grid, "سرعت (km/h)");
        loadText = addTile(grid, "بار موتور (%)");
        throttleText = addTile(grid, "دریچه گاز (%)");
        voltText = addTile(grid, "ولتاژ باتری");
        root.addView(grid, fullWidth());

        // Alarm setting
        TextView alarmLabel = label("هشدار وقتی دمای آب به این عدد (°C) برسد:", 14, Color.parseColor("#9AA4AE"));
        alarmLabel.setPadding(0, dp(20), 0, dp(4));
        root.addView(alarmLabel);
        LinearLayout alarmRow = new LinearLayout(this);
        alarmRow.setOrientation(LinearLayout.HORIZONTAL);
        alarmEdit = new EditText(this);
        alarmEdit.setInputType(InputType.TYPE_CLASS_NUMBER);
        alarmEdit.setText(String.valueOf(alarmTemp));
        alarmEdit.setTextColor(Color.WHITE);
        alarmEdit.setEms(4);
        alarmRow.addView(alarmEdit);
        Button saveAlarm = button("ذخیره");
        saveAlarm.setOnClickListener(v -> saveAlarm());
        alarmRow.addView(saveAlarm);
        root.addView(alarmRow);

        // DTC
        TextView dtcLabel = label("کدهای خطا", 18, Color.WHITE);
        dtcLabel.setTypeface(Typeface.DEFAULT_BOLD);
        dtcLabel.setPadding(0, dp(24), 0, dp(4));
        root.addView(dtcLabel);
        readDtcBtn = button("خواندن کدهای خطا");
        readDtcBtn.setOnClickListener(v -> jobs.offer(this::readDtcs));
        root.addView(readDtcBtn, fullWidth());
        clearDtcBtn = button("پاک کردن کدهای خطا");
        clearDtcBtn.setOnClickListener(v -> confirmClearDtcs());
        root.addView(clearDtcBtn, fullWidth());
        dtcText = label("", 16, Color.WHITE);
        dtcText.setPadding(0, dp(8), 0, dp(8));
        dtcText.setTextIsSelectable(true);
        root.addView(dtcText);

        TextView note = label("این برنامه فقط اطلاعات را می‌خواند و چیزی روی ECU نمی‌نویسد (به‌جز پاک کردن کدهای خطا).",
                12, Color.parseColor("#6B7680"));
        note.setPadding(0, dp(16), 0, 0);
        root.addView(note);

        setContentView(scroll);
    }

    private TextView addTile(GridLayout grid, String name) {
        LinearLayout tile = new LinearLayout(this);
        tile.setOrientation(LinearLayout.VERTICAL);
        tile.setPadding(dp(8), dp(10), dp(8), dp(10));
        tile.addView(label(name, 12, Color.parseColor("#9AA4AE")));
        TextView value = label("—", 26, Color.WHITE);
        value.setTypeface(Typeface.DEFAULT_BOLD);
        tile.addView(value);
        GridLayout.LayoutParams lp = new GridLayout.LayoutParams(
                GridLayout.spec(GridLayout.UNDEFINED, 1f), GridLayout.spec(GridLayout.UNDEFINED, 1f));
        lp.width = 0;
        grid.addView(tile, lp);
        return value;
    }

    private TextView label(String text, int sp, int color) {
        TextView t = new TextView(this);
        t.setText(text);
        t.setTextSize(sp);
        t.setTextColor(color);
        t.setGravity(Gravity.START);
        return t;
    }

    private Button button(String text) {
        Button b = new Button(this);
        b.setText(text);
        b.setAllCaps(false);
        return b;
    }

    private LinearLayout.LayoutParams fullWidth() {
        return new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT);
    }

    private int dp(int v) {
        return Math.round(v * getResources().getDisplayMetrics().density);
    }

    private void setStatus(String s) {
        runOnUiThread(() -> statusText.setText(s));
    }

    private void setConnectedUi(boolean connected) {
        runOnUiThread(() -> {
            connectBtn.setText(connected ? "قطع اتصال" : "اتصال به OBD");
            readDtcBtn.setEnabled(connected);
            clearDtcBtn.setEnabled(connected);
        });
    }

    private void saveAlarm() {
        try {
            int v = Integer.parseInt(alarmEdit.getText().toString().trim());
            if (v < 60 || v > 130) {
                toast("عدد باید بین ۶۰ تا ۱۳۰ باشد");
                return;
            }
            alarmTemp = v;
            getSharedPreferences(PREFS, MODE_PRIVATE).edit().putInt(KEY_ALARM, v).apply();
            toast("ذخیره شد");
        } catch (NumberFormatException e) {
            toast("عدد معتبر وارد کنید");
        }
    }

    private void toast(String s) {
        runOnUiThread(() -> Toast.makeText(this, s, Toast.LENGTH_SHORT).show());
    }

    // ---------------------------------------------------------- Bluetooth

    private boolean hasBtPermission() {
        if (Build.VERSION.SDK_INT >= 31) {
            return checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) == PackageManager.PERMISSION_GRANTED;
        }
        return true;
    }

    private void startConnectFlow() {
        if (!hasBtPermission()) {
            requestPermissions(new String[]{Manifest.permission.BLUETOOTH_CONNECT}, REQ_BT);
            return;
        }
        showDevicePicker();
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQ_BT) {
            if (hasBtPermission()) showDevicePicker();
            else toast("بدون اجازه‌ی بلوتوث نمی‌شود وصل شد");
        }
    }

    @SuppressLint("MissingPermission")
    private void showDevicePicker() {
        BluetoothManager bm = (BluetoothManager) getSystemService(Context.BLUETOOTH_SERVICE);
        BluetoothAdapter adapter = bm == null ? null : bm.getAdapter();
        if (adapter == null) {
            toast("این گوشی بلوتوث ندارد");
            return;
        }
        if (!adapter.isEnabled()) {
            toast("اول بلوتوث گوشی را روشن کنید");
            return;
        }
        Set<BluetoothDevice> bonded = adapter.getBondedDevices();
        if (bonded == null || bonded.isEmpty()) {
            new AlertDialog.Builder(this)
                    .setTitle("دستگاهی پیدا نشد")
                    .setMessage("اول در تنظیمات بلوتوث گوشی، OBD را جفت (Pair) کنید. رمز معمولاً 1234 یا 0000 است.")
                    .setPositiveButton("باشه", null)
                    .show();
            return;
        }
        final List<BluetoothDevice> devices = new ArrayList<>(bonded);
        String last = getSharedPreferences(PREFS, MODE_PRIVATE).getString(KEY_LAST_DEVICE, "");
        String[] names = new String[devices.size()];
        for (int i = 0; i < devices.size(); i++) {
            BluetoothDevice d = devices.get(i);
            String n = d.getName() == null ? "(بی‌نام)" : d.getName();
            names[i] = n + "\n" + d.getAddress() + (d.getAddress().equals(last) ? "  ★" : "");
        }
        new AlertDialog.Builder(this)
                .setTitle("دستگاه OBD را انتخاب کنید")
                .setItems(names, (dialog, which) -> connectTo(devices.get(which)))
                .setNegativeButton("انصراف", null)
                .show();
    }

    private void connectTo(BluetoothDevice device) {
        getSharedPreferences(PREFS, MODE_PRIVATE).edit().putString(KEY_LAST_DEVICE, device.getAddress()).apply();
        running = true;
        jobs.clear();
        setConnectedUi(true);
        worker = new Thread(() -> workerLoop(device), "obd-worker");
        worker.start();
    }

    private void disconnect() {
        running = false;
        if (worker != null) worker.interrupt();
        elm.close();
        setConnectedUi(false);
        setStatus("قطع شد");
    }

    // ------------------------------------------------------------ Worker

    private void workerLoop(BluetoothDevice device) {
        try {
            setStatus("در حال اتصال به آداپتور...");
            elm.connect(device);
            setStatus("در حال برقراری ارتباط با ECU (سوییچ باید باز باشد)...");
            String r = elm.init();
            if (ObdParser.pidData(r, 1, 0) == null) {
                setStatus("آداپتور وصل شد ولی ECU جواب نداد: " + ObdParser.lines(r)
                        + "\nسوییچ را باز کنید یا موتور را روشن کنید و دوباره وصل شوید.");
                elm.close();
                running = false;
                setConnectedUi(false);
                return;
            }
            int[] baro = elm.readPid(0x33);
            if (baro != null && baro.length >= 1 && baro[0] > 50) baroKpa = baro[0];
            setStatus("وصل است — " + elm.protocolName());

            int cycle = 0;
            while (running) {
                Runnable job = jobs.poll();
                if (job != null) {
                    job.run();
                    continue;
                }
                pollOnce(cycle++);
            }
        } catch (IOException e) {
            if (running) setStatus("اتصال قطع شد: " + e.getMessage());
        } finally {
            running = false;
            elm.close();
            setConnectedUi(false);
        }
    }

    private void pollOnce(int cycle) throws IOException {
        int[] d;

        d = elm.readPid(0x05); // coolant
        final Integer coolant = (d != null && d.length >= 1) ? d[0] - 40 : null;
        runOnUiThread(() -> showCoolant(coolant));
        if (coolant != null) checkAlarm(coolant);

        d = elm.readPid(0x0C); // rpm
        setValue(rpmText, (d != null && d.length >= 2) ? String.valueOf((d[0] * 256 + d[1]) / 4) : null);

        d = elm.readPid(0x0B); // MAP kPa
        if (d != null && d.length >= 1) {
            double boost = (d[0] - baroKpa) / 100.0;
            setValue(boostText, String.format(java.util.Locale.US, "%+.2f", boost));
        } else setValue(boostText, null);

        d = elm.readPid(0x0D); // speed
        setValue(speedText, (d != null && d.length >= 1) ? String.valueOf(d[0]) : null);

        if (cycle % 3 == 0) {
            d = elm.readPid(0x0F); // intake air temp
            setValue(iatText, (d != null && d.length >= 1) ? (d[0] - 40) + "°" : null);

            d = elm.readPid(0x04); // load
            setValue(loadText, (d != null && d.length >= 1) ? String.valueOf(Math.round(d[0] * 100 / 255.0)) : null);

            d = elm.readPid(0x11); // throttle
            setValue(throttleText, (d != null && d.length >= 1) ? String.valueOf(Math.round(d[0] * 100 / 255.0)) : null);
        }
        if (cycle % 10 == 0) {
            double v = ObdParser.parseVoltage(elm.send("ATRV", 1500));
            setValue(voltText, Double.isNaN(v) ? null : String.format(java.util.Locale.US, "%.1fV", v));
        }
    }

    private void setValue(TextView tv, String value) {
        runOnUiThread(() -> tv.setText(value == null ? "—" : value));
    }

    private void showCoolant(Integer c) {
        if (c == null) {
            coolantText.setText("—");
            coolantText.setTextColor(Color.WHITE);
            return;
        }
        coolantText.setText(c + "°C");
        if (c >= alarmTemp) coolantText.setTextColor(Color.parseColor("#FF4D4D"));
        else if (c >= alarmTemp - 5) coolantText.setTextColor(Color.parseColor("#FFB020"));
        else if (c < 70) coolantText.setTextColor(Color.parseColor("#5AB0FF"));
        else coolantText.setTextColor(Color.parseColor("#4CD07D"));
    }

    @SuppressWarnings("deprecation")
    private void checkAlarm(int coolant) {
        if (coolant < alarmTemp) return;
        long now = System.currentTimeMillis();
        if (now - lastAlarmAt < 5000) return;
        lastAlarmAt = now;
        if (tone != null) tone.startTone(ToneGenerator.TONE_CDMA_ALERT_CALL_GUARD, 800);
        Vibrator vib = (Vibrator) getSystemService(Context.VIBRATOR_SERVICE);
        if (vib != null && vib.hasVibrator()) {
            if (Build.VERSION.SDK_INT >= 26) vib.vibrate(VibrationEffect.createOneShot(600, VibrationEffect.DEFAULT_AMPLITUDE));
            else vib.vibrate(600);
        }
        toast("هشدار: دمای آب " + coolant + "°C");
    }

    // --------------------------------------------------------------- DTC

    private void readDtcs() {
        try {
            runOnUiThread(() -> dtcText.setText("در حال خواندن..."));
            List<String> stored = ObdParser.parseDtcs(elm.send("03", 8000), 3, elm.isCan());
            List<String> pending = ObdParser.parseDtcs(elm.send("07", 8000), 7, elm.isCan());
            StringBuilder sb = new StringBuilder();
            sb.append("کدهای ثبت‌شده: ").append(stored.isEmpty() ? "ندارد" : TextUtils.join("  ", stored));
            sb.append("\nکدهای در انتظار: ").append(pending.isEmpty() ? "ندارد" : TextUtils.join("  ", pending));
            final String s = sb.toString();
            runOnUiThread(() -> dtcText.setText(s));
        } catch (IOException e) {
            runOnUiThread(() -> dtcText.setText("خطا: " + e.getMessage()));
            running = false;
        }
    }

    private void confirmClearDtcs() {
        new AlertDialog.Builder(this)
                .setTitle("پاک کردن کدهای خطا")
                .setMessage("موتور خاموش و سوییچ باز باشد.\n\nبا این کار چراغ چک خاموش می‌شود، ولی اگر ایراد واقعی باشد دوباره روشن می‌شود. اطلاعات Freeze Frame و وضعیت Readiness هم پاک می‌شود.\n\nادامه می‌دهید؟")
                .setPositiveButton("پاک کن", (d, w) -> jobs.offer(this::clearDtcs))
                .setNegativeButton("انصراف", null)
                .show();
    }

    private void clearDtcs() {
        try {
            String r = elm.send("04", 8000);
            boolean ok = r.toUpperCase().replace(" ", "").contains("44");
            final String s = ok ? "کدها پاک شد." : "ECU پاک کردن را قبول نکرد: " + ObdParser.lines(r);
            runOnUiThread(() -> dtcText.setText(s));
        } catch (IOException e) {
            runOnUiThread(() -> dtcText.setText("خطا: " + e.getMessage()));
            running = false;
        }
    }

    @Override
    protected void onDestroy() {
        running = false;
        if (worker != null) worker.interrupt();
        elm.close();
        if (tone != null) tone.release();
        super.onDestroy();
    }
}
