package ir.obd.mg360;

import android.Manifest;
import android.animation.ObjectAnimator;
import android.animation.ValueAnimator;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.AlertDialog;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.content.res.Configuration;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.hardware.usb.UsbDevice;
import android.hardware.usb.UsbManager;
import android.media.AudioManager;
import android.net.ConnectivityManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.text.InputType;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import com.hoho.android.usbserial.driver.UsbSerialDriver;
import com.hoho.android.usbserial.driver.UsbSerialProber;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.LinkedBlockingQueue;

public class MainActivity extends Activity {

    private static final int REQ_BT = 1;
    private static final String PREFS = "settings";
    private static final String KEY_ALARM = "coolant_alarm";
    private static final String KEY_SPEED_ALARM = "speed_alarm";
    private static final String KEY_SPEED_INT = "speed_alarm_interval";
    private static final String KEY_COOL_INT = "coolant_alarm_interval";
    private static final String KEY_LAST_DEVICE = "last_device";
    private static final String KEY_AUTO = "auto_connect";
    private static final String KEY_WIFI_HOST = "wifi_host";
    private static final String KEY_WIFI_PORT = "wifi_port";
    private static final String KEY_LOGO = "logo_uri";
    private static final String KEY_SUPPORTED = "supported_pids";
    private static final String KEY_BG = "background_style";
    private static final String KEY_LAYOUT = "dash_layout";
    private static final int REQ_LOGO = 2;
    private static final String ACTION_USB_PERMISSION = "ir.obd.mg360.USB_PERMISSION";

    // Colours
    private static final int BG = Color.parseColor("#06080B");
    private static final int TEXT_DIM = Color.parseColor("#8C98A6");
    private static final int GREEN = Color.parseColor("#00E676");
    private static final int ORANGE = Color.parseColor("#FFB020");
    private static final int RED = Color.parseColor("#FF3B30");
    private static final int CYAN = Color.parseColor("#00E5FF");

    // UI (rebuilt on rotation)
    private GaugeView rpmGauge, boostGauge, coolantGauge, speedGauge, iatGauge;
    private BarGaugeView coolantBar;
    private final TileView[] tiles = new TileView[6];
    private static final String[] DEFAULT_SLOTS = {"trip", "pid:0F", "pid:04", "pid:11", "volt", "peak"};
    private static final int[] SLOT_COLORS = {Color.parseColor("#00E5FF"), Color.parseColor("#40C4FF"),
            Color.parseColor("#B388FF"), Color.parseColor("#00E676"), Color.parseColor("#FFD54F"),
            Color.parseColor("#FF6D00")};
    private TextView statusText, rateText;
    private View statusDot, alarmOverlay;
    private Button connectBtn;
    private ObjectAnimator alarmAnim;
    private TurboBadge badge;
    private boolean btPermissionAsked = false;
    private boolean compactBar = false;

    // Latest readings (written by worker, read on UI thread). NaN = no data.
    private volatile float vRpm = Float.NaN, vSpeed = Float.NaN, vBoost = Float.NaN, vCoolant = Float.NaN,
            vIat = Float.NaN, vLoad = Float.NaN, vThrottle = Float.NaN, vVolt = Float.NaN;
    private volatile float rateHz = 0f;
    private volatile double tripKm = 0;
    /** Latest value of every mode-01 PID read, already converted (pid -> value). */
    private final Map<Integer, Double> pidValues = new java.util.concurrent.ConcurrentHashMap<>();
    private volatile boolean multiMode = false;
    private volatile String[] slots = DEFAULT_SLOTS.clone();
    private volatile java.util.Set<Integer> supported = new java.util.TreeSet<>();
    private long lastSpeedAt = 0;
    private volatile String statusMsg = "وصل نیست";
    private volatile int statusColor = Color.parseColor("#4A5562");

    // Connection
    private final Elm327 elm = new Elm327();
    private final LinkedBlockingQueue<Runnable> jobs = new LinkedBlockingQueue<>();
    private volatile boolean running = false;
    private volatile Thread worker;
    private int baroKpa = 101;

    private int alarmTemp = 105;
    private int speedAlarm = 0;          // km/h, 0 = off
    private int speedIntervalMin = 5;
    private int coolantIntervalMin = 4;
    private boolean speedAlertOn = false, coolantAlertOn = false;
    private long lastSpeedAlert = 0, lastCoolantAlert = 0;
    private AlertPlayer alerts;
    private boolean alarmActive = false;
    private SharedPreferences prefs;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        getWindow().setStatusBarColor(BG);
        getWindow().setNavigationBarColor(BG);
        prefs = getSharedPreferences(PREFS, MODE_PRIVATE);
        alarmTemp = prefs.getInt(KEY_ALARM, 105);
        speedAlarm = prefs.getInt(KEY_SPEED_ALARM, 0);
        speedIntervalMin = prefs.getInt(KEY_SPEED_INT, 5);
        coolantIntervalMin = prefs.getInt(KEY_COOL_INT, 4);
        loadSlots();
        alerts = new AlertPlayer(this);
        buildUi();
        applyValues();

        if (!handleUsbAttach(getIntent())
                && prefs.getBoolean(KEY_AUTO, true) && !prefs.getString(KEY_LAST_DEVICE, "").isEmpty()) {
            autoConnect();
        }
    }

    @Override
    public void onConfigurationChanged(Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
        float peak = boostGauge != null ? boostGauge.getPeak() : Float.NaN;
        buildUi();
        if (!Float.isNaN(peak)) boostGauge.setValue(peak); // restore peak marker
        applyValues();
    }

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus) hideSystemBars();
    }

    @SuppressWarnings("deprecation")
    private void hideSystemBars() {
        getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                        | View.SYSTEM_UI_FLAG_FULLSCREEN
                        | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                        | View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                        | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                        | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN);
    }

    // =================================================================== UI

    private void buildUi() {
        boolean landscape = getResources().getConfiguration().orientation == Configuration.ORIENTATION_LANDSCAPE;
        compactBar = getResources().getConfiguration().screenWidthDp < 600;

        FrameLayout frame = new FrameLayout(this);
        frame.setBackgroundColor(BG);
        BackgroundView bgView = new BackgroundView(this);
        bgView.setStyle(prefs.getString(KEY_BG, BackgroundView.CARBON));
        frame.addView(bgView, new FrameLayout.LayoutParams(-1, -1));

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        root.setPadding(dp(10), dp(6), dp(10), dp(8));
        frame.addView(root, new FrameLayout.LayoutParams(-1, -1));

        View topBar = buildTopBar();
        if (landscape) {
            // floating over the dashboard so the gauges get the full height
            root.setPadding(dp(10), dp(4), dp(10), dp(8));
        } else {
            root.addView(topBar, new LinearLayout.LayoutParams(-1, dp(52)));
        }

        rpmGauge = new GaugeView(this, "RPM", "دور موتور", 0, 7000, 1000, 0,
                new int[]{CYAN, Color.parseColor("#2979FF"), Color.parseColor("#D500F9")})
                .setRedFrom(6000).setLabelDivider(1000);
        boostGauge = new GaugeView(this, "BOOST", "bar  فشار توربو", -1f, 2f, 0.5f, 2,
                new int[]{Color.parseColor("#2979FF"), GREEN, Color.parseColor("#FFEA00"),
                        Color.parseColor("#FF6D00"), Color.parseColor("#FF1744")})
                .setShowPeak(true);
        coolantGauge = new GaugeView(this, "COOLANT", "°C  دمای آب", 40, 130, 10, 0,
                new int[]{Color.parseColor("#2979FF"), CYAN, GREEN, Color.parseColor("#FFC400"),
                        Color.parseColor("#FF1744")})
                .setRedFrom(alarmTemp);
        iatGauge = new GaugeView(this, "INTAKE", "°C  هوای ورودی", -20, 80, 20, 0,
                new int[]{Color.parseColor("#2979FF"), CYAN, GREEN, Color.parseColor("#FFC400"),
                        Color.parseColor("#FF1744")})
                .setRedFrom(60);
        coolantBar = new BarGaugeView(this, "دمای آب", "°C", 40, 130, alarmTemp);

        speedGauge = new GaugeView(this, "SPEED", "km/h", 0, 240, 40, 0,
                new int[]{CYAN, Color.parseColor("#00B0FF"), Color.parseColor("#76FF03"),
                        Color.parseColor("#FFEA00"), Color.parseColor("#FF1744")})
                .setRedFrom(speedAlarm > 0 ? speedAlarm : 140).setDigitalCenter(true);
        for (int i = 0; i < tiles.length; i++) tiles[i] = makeTile(i);

        if (landscape) {
            DashboardLayout gauges = new DashboardLayout(this);
            gauges.setLayoutDirection(View.LAYOUT_DIRECTION_LTR);
            // positions in a 1024 x 424 design canvas; the speedometer is added last so it sits on top
            switch (prefs.getString(KEY_LAYOUT, "B")) {
                case "A": // classic trio + coolant bar
                    gauges.addGauge(rpmGauge, 178, 204, 122);
                    gauges.addGauge(boostGauge, 846, 204, 122);
                    gauges.addBox(coolantBar, 372, 372, 280, 40);
                    gauges.addGauge(speedGauge, 512, 192, 165);
                    break;
                case "C": // sport cluster, small corner gauges
                    gauges.addGauge(coolantGauge, 62, 362, 50);
                    gauges.addGauge(iatGauge, 962, 362, 50);
                    gauges.addGauge(rpmGauge, 216, 204, 130);
                    gauges.addGauge(boostGauge, 808, 204, 130);
                    gauges.addGauge(speedGauge, 512, 204, 182);
                    break;
                case "D": // sport cluster, large corner gauges
                    gauges.addGauge(rpmGauge, 236, 190, 128);
                    gauges.addGauge(boostGauge, 788, 190, 128);
                    gauges.addGauge(coolantGauge, 86, 342, 72);
                    gauges.addGauge(iatGauge, 938, 342, 72);
                    gauges.addGauge(speedGauge, 512, 204, 182);
                    break;
                default: // "B": symmetric 4 + 1
                    gauges.addGauge(rpmGauge, 150, 107, 90);
                    gauges.addGauge(coolantGauge, 150, 314, 90);
                    gauges.addGauge(boostGauge, 874, 107, 90);
                    gauges.addGauge(iatGauge, 874, 314, 90);
                    gauges.addGauge(speedGauge, 512, 207, 180);
            }
            root.addView(gauges, new LinearLayout.LayoutParams(-1, 0, 1f));

            LinearLayout tileRow = new LinearLayout(this);
            tileRow.setOrientation(LinearLayout.HORIZONTAL);
            for (TileView t : tiles) {
                tileRow.addView(t, new LinearLayout.LayoutParams(0, -1, 1f));
            }
            root.addView(tileRow, new LinearLayout.LayoutParams(-1, 0, 0.30f));
        } else {
            root.addView(speedGauge, new LinearLayout.LayoutParams(-1, 0, 1.0f));
            LinearLayout row = new LinearLayout(this);
            row.setOrientation(LinearLayout.HORIZONTAL);
            row.setLayoutDirection(View.LAYOUT_DIRECTION_LTR);
            row.addView(rpmGauge, new LinearLayout.LayoutParams(0, -1, 1f));
            row.addView(boostGauge, new LinearLayout.LayoutParams(0, -1, 1f));
            row.addView(coolantGauge, new LinearLayout.LayoutParams(0, -1, 1f));
            root.addView(row, new LinearLayout.LayoutParams(-1, 0, 0.5f));
            TileView[][] grid = {{tiles[0], tiles[1]}, {tiles[2], tiles[3]}, {tiles[4], tiles[5]}};
            for (TileView[] pair : grid) {
                LinearLayout r = new LinearLayout(this);
                r.setOrientation(LinearLayout.HORIZONTAL);
                for (TileView t : pair) r.addView(t, new LinearLayout.LayoutParams(0, -1, 1f));
                root.addView(r, new LinearLayout.LayoutParams(-1, 0, 0.17f));
            }
        }

        // Red pulsing border shown while the coolant alarm is active
        alarmOverlay = new View(this);
        GradientDrawable border = new GradientDrawable();
        border.setColor(Color.TRANSPARENT);
        border.setStroke(dp(8), RED);
        border.setCornerRadius(dp(4));
        alarmOverlay.setBackground(border);
        alarmOverlay.setVisibility(View.GONE);
        if (landscape) {
            topBar.setPadding(dp(12), dp(6), dp(12), 0);
            frame.addView(topBar, new FrameLayout.LayoutParams(-1, dp(58), Gravity.TOP));
        }
        frame.addView(alarmOverlay, new FrameLayout.LayoutParams(-1, -1));
        alarmAnim = ObjectAnimator.ofFloat(alarmOverlay, "alpha", 1f, 0.15f);
        alarmAnim.setDuration(450);
        alarmAnim.setRepeatMode(ValueAnimator.REVERSE);
        alarmAnim.setRepeatCount(ValueAnimator.INFINITE);
        alarmActive = false;

        setContentView(frame);
        updateConnectButton();
        loadLogo();
    }

    private View buildTopBar() {
        LinearLayout bar = new LinearLayout(this);
        bar.setOrientation(LinearLayout.HORIZONTAL);
        bar.setGravity(Gravity.CENTER_VERTICAL);
        bar.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);

        TextView brand = new TextView(this);
        brand.setText("MG360 TURBO");
        brand.setTextColor(Color.WHITE);
        brand.setTextSize(18);
        brand.setLetterSpacing(0.15f);
        brand.setTypeface(Typeface.create("sans-serif-condensed", Typeface.BOLD));
        badge = new TurboBadge(this);
        LinearLayout.LayoutParams blp = new LinearLayout.LayoutParams(dp(44), dp(44));
        blp.setMargins(0, 0, 0, 0);
        bar.addView(badge, blp);
        LinearLayout.LayoutParams brlp = new LinearLayout.LayoutParams(-2, -2);
        brlp.setMarginStart(dp(10));
        bar.addView(brand, brlp);
        if (compactBar) brand.setVisibility(View.GONE);

        statusDot = new View(this);
        GradientDrawable dot = new GradientDrawable();
        dot.setShape(GradientDrawable.OVAL);
        dot.setColor(statusColor);
        statusDot.setBackground(dot);
        LinearLayout.LayoutParams dlp = new LinearLayout.LayoutParams(dp(10), dp(10));
        dlp.setMargins(dp(14), 0, dp(8), 0);
        bar.addView(statusDot, dlp);

        statusText = new TextView(this);
        statusText.setTextColor(TEXT_DIM);
        statusText.setTextSize(13);
        statusText.setSingleLine(true);
        statusText.setEllipsize(TextUtils.TruncateAt.END);
        statusText.setText(statusMsg);
        statusText.setMaxWidth(dp(compactBar ? 160 : 230));
        bar.addView(statusText, new LinearLayout.LayoutParams(-2, -2));
        bar.addView(new View(this), new LinearLayout.LayoutParams(0, 1, 1f)); // spacer

        rateText = new TextView(this);
        rateText.setTextColor(Color.parseColor("#4A5562"));
        rateText.setTextSize(12);
        rateText.setTypeface(Typeface.MONOSPACE);
        LinearLayout.LayoutParams rlp = new LinearLayout.LayoutParams(-2, -2);
        rlp.setMargins(dp(8), 0, dp(8), 0);
        bar.addView(rateText, rlp);

        IconView gear = new IconView(this, IconView.GEAR, CYAN, true);
        gear.setOnClickListener(v -> showMainMenu());
        LinearLayout.LayoutParams glp = new LinearLayout.LayoutParams(dp(46), dp(46));
        glp.setMarginStart(dp(6));
        bar.addView(gear, glp);
        return bar;
    }

    private Button pill(String text, int color) {
        Button b = new Button(this);
        b.setText(text);
        b.setAllCaps(false);
        b.setTextSize(14);
        b.setTextColor(color);
        b.setMinHeight(0);
        b.setMinimumHeight(0);
        b.setPadding(dp(compactBar ? 9 : 16), 0, dp(compactBar ? 9 : 16), 0);
        if (compactBar) b.setTextSize(12);
        b.setStateListAnimator(null);
        GradientDrawable g = new GradientDrawable();
        g.setColor(Color.parseColor("#121920"));
        g.setStroke(dp(1), (color & 0x00FFFFFF) | 0x66000000);
        g.setCornerRadius(dp(20));
        b.setBackground(g);
        return b;
    }

    private LinearLayout.LayoutParams pillLp() {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-2, dp(38));
        lp.setMargins(dp(4), 0, dp(4), 0);
        return lp;
    }

    private int dp(int v) {
        return Math.round(v * getResources().getDisplayMetrics().density);
    }

    private void toast(String s) {
        runOnUiThread(() -> Toast.makeText(this, s, Toast.LENGTH_SHORT).show());
    }

    private void setStatus(String msg, int color) {
        statusMsg = msg;
        statusColor = color;
        runOnUiThread(this::applyStatus);
    }

    private void applyStatus() {
        if (statusText == null) return;
        statusText.setText(statusMsg);
        ((GradientDrawable) statusDot.getBackground()).setColor(statusColor);
        updateConnectButton();
    }

    private void updateConnectButton() {
        if (connectBtn != null) connectBtn.setText(running ? "قطع" : "اتصال");
    }

    /** Pushes the latest readings into the views. Runs on the UI thread. */
    private void applyValues() {
        if (rpmGauge == null) return;
        rpmGauge.setValue(vRpm);
        boostGauge.setValue(vBoost);
        coolantGauge.setValue(vCoolant);
        iatGauge.setValue(vIat);
        coolantBar.setValue(vCoolant);

        speedGauge.setValue(vSpeed);
        for (int i = 0; i < tiles.length; i++) updateTile(i);

        badge.setIntensity(Float.isNaN(vBoost) ? 0f : vBoost / 1.5f);
        rateText.setText(running && rateHz > 0 ? String.format(Locale.US, "%.0f Hz", rateHz) : "");

        boolean hot = !Float.isNaN(vCoolant) && vCoolant >= alarmTemp;
        setAlarmVisual(hot);
    }

    private static String fmt0(float v) {
        return Float.isNaN(v) ? "--" : String.valueOf(Math.round(v));
    }

    private void setAlarmVisual(boolean on) {
        if (on == alarmActive) return;
        alarmActive = on;
        if (on) {
            alarmOverlay.setVisibility(View.VISIBLE);
            alarmAnim.start();
        } else {
            alarmAnim.cancel();
            alarmOverlay.setVisibility(View.GONE);
        }
    }

    // ============================================================== Tiles

    private void loadSlots() {
        String[] sl = DEFAULT_SLOTS.clone();
        for (int i = 0; i < sl.length; i++) sl[i] = prefs.getString("tile" + i, sl[i]);
        slots = sl;
        java.util.Set<Integer> sup = new java.util.TreeSet<>();
        for (String x : prefs.getString(KEY_SUPPORTED, "").split(",")) {
            try {
                if (!x.isEmpty()) sup.add(Integer.parseInt(x, 16));
            } catch (NumberFormatException ignored) {
            }
        }
        supported = sup;
    }

    private static int slotPid(String slot) {
        if (!slot.startsWith("pid:")) return -1;
        try {
            return Integer.parseInt(slot.substring(4), 16);
        } catch (NumberFormatException e) {
            return -1;
        }
    }

    private TileView makeTile(int i) {
        String slot = slots[i];
        int color = SLOT_COLORS[i % SLOT_COLORS.length];
        TileView t;
        switch (slot) {
            case "trip":
                t = new TileView(this, "مسافت سفر", "km", color, false);
                t.setOnClickListener(v -> {
                    tripKm = 0;
                    applyValues();
                    toast("مسافت سفر صفر شد");
                });
                break;
            case "volt":
                t = new TileView(this, "ولتاژ باتری", "V", color, false);
                break;
            case "peak":
                t = new TileView(this, "بیشترین بوست", "bar", color, false);
                t.setOnClickListener(v -> {
                    boostGauge.resetPeak();
                    applyValues();
                    toast("بیشترین بوست صفر شد");
                });
                break;
            case "speed":
                t = new TileView(this, "سرعت", "km/h", color, false);
                break;
            default:
                PidCatalog.Pid def = PidCatalog.get(slotPid(slot));
                if (def == null) {
                    t = new TileView(this, "؟", "", color, false);
                } else {
                    t = new TileView(this, def.name, def.unit, color, !Double.isNaN(def.barMax));
                }
        }
        final int idx = i;
        t.setOnLongClickListener(v -> {
            chooseTileContent(idx);
            return true;
        });
        return t;
    }

    private void updateTile(int i) {
        TileView t = tiles[i];
        if (t == null) return;
        String slot = slots[i];
        int warn = Color.WHITE;
        switch (slot) {
            case "trip":
                t.setValue(String.format(Locale.US, "%.1f", tripKm));
                break;
            case "volt":
                t.setValue(Float.isNaN(vVolt) ? "--" : String.format(Locale.US, "%.1f", vVolt));
                if (!Float.isNaN(vVolt) && (vVolt < 11.8f || vVolt > 14.9f)) warn = ORANGE;
                break;
            case "peak":
                float peak = boostGauge.getPeak();
                t.setValue(Float.isNaN(peak) ? "--" : String.format(Locale.US, "%+.2f", peak));
                break;
            case "speed":
                t.setValue(fmt0(vSpeed));
                break;
            default:
                int pid = slotPid(slot);
                PidCatalog.Pid def = PidCatalog.get(pid);
                Double v = pidValues.get(pid);
                if (def == null || v == null) {
                    t.setValue("--");
                    t.setBar(0);
                } else {
                    t.setValue(def.format(v));
                    if (!Double.isNaN(def.barMax)) t.setBar((float) (v / def.barMax));
                    if ((pid == 0x0F && v >= 60) || (pid == 0x5C && v >= 120)) warn = ORANGE;
                }
        }
        t.setValueColor(warn);
    }

    /** Long-press on a tile: pick what it shows. */
    private void chooseTileContent(int idx) {
        final List<String> keys = new ArrayList<>();
        final List<String> names = new ArrayList<>();
        keys.add("trip");
        names.add("مسافت سفر");
        keys.add("volt");
        names.add("ولتاژ باتری");
        keys.add("peak");
        names.add("بیشترین بوست");
        keys.add("speed");
        names.add("سرعت (عددی)");
        boolean scanned = !supported.isEmpty();
        for (PidCatalog.Pid p : PidCatalog.all()) {
            if (scanned && !supported.contains(p.pid)) continue;
            keys.add(String.format(Locale.US, "pid:%02X", p.pid));
            names.add(p.name + (p.unit.isEmpty() ? "" : "  (" + p.unit + ")"));
        }
        new AlertDialog.Builder(this)
                .setTitle(scanned ? "این کارت چه چیزی نشان دهد؟" : "این کارت چه چیزی نشان دهد؟\n(برای دیدن فقط موارد پشتیبانی‌شده، اول «اسکن» بزنید)")
                .setItems(names.toArray(new String[0]), (d, which) -> {
                    String[] sl = slots.clone();
                    sl[idx] = keys.get(which);
                    slots = sl;
                    prefs.edit().putString("tile" + idx, sl[idx]).apply();
                    float peak = boostGauge.getPeak();
                    buildUi();
                    if (!Float.isNaN(peak)) boostGauge.setValue(peak);
                    applyValues();
                })
                .setNegativeButton("انصراف", null)
                .show();
    }

    // =============================================================== Scan

    private void showScanDialog() {
        ScrollView sv = new ScrollView(this);
        TextView result = new TextView(this);
        result.setPadding(dp(24), dp(12), dp(24), dp(12));
        result.setTextSize(15);
        result.setTextColor(Color.WHITE);
        result.setTextIsSelectable(true);
        result.setLineSpacing(0, 1.25f);
        result.setText(running ? "در حال اسکن... (چند ثانیه)" : "اول به OBD وصل شوید.");
        sv.addView(result);
        AlertDialog dlg = new AlertDialog.Builder(this)
                .setTitle("اسکن قابلیت‌های ECU")
                .setView(sv)
                .setPositiveButton("اسکن دوباره", null)
                .setNegativeButton("بستن", null)
                .create();
        dlg.setOnShowListener(d -> dlg.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v -> {
            if (!running) {
                toast("اول وصل شوید");
                return;
            }
            result.setText("در حال اسکن... (چند ثانیه)");
            jobs.offer(() -> scan(result));
        }));
        dlg.show();
        if (running) jobs.offer(() -> scan(result));
    }

    /** Runs on the worker thread. */
    private void scan(TextView result) {
        StringBuilder sb = new StringBuilder();
        try {
            java.util.Set<Integer> sup = new java.util.TreeSet<>();
            int base = 0x00;
            while (base <= 0xC0) {
                int[] d = elm.readPid(base);
                if (d == null || d.length < 4) break;
                java.util.Set<Integer> part = PidCatalog.decodeSupported(base, d);
                sup.addAll(part);
                if (!part.contains(base + 0x20)) break; // next range not supported
                base += 0x20;
            }
            String vin = ObdParser.parseVin(elm.send("0902", 5000));
            if (!vin.isEmpty()) sb.append("شماره شاسی (VIN): ").append(vin).append("\n");
            sb.append("پروتکل: ").append(elm.isCan() ? "CAN" : "K-Line")
                    .append(multiMode ? " (خواندن چندتایی فعال)" : "").append("\n\n");

            // read current values of everything supported
            List<Integer> known = new ArrayList<>();
            for (int pid : sup) if (PidCatalog.get(pid) != null) known.add(pid);
            Map<Integer, int[]> vals = new java.util.HashMap<>();
            if (multiMode) {
                for (int i = 0; i < known.size(); i += 6) {
                    List<Integer> chunk = known.subList(i, Math.min(known.size(), i + 6));
                    int[] arr = new int[chunk.size()];
                    for (int k = 0; k < arr.length; k++) arr[k] = chunk.get(k);
                    vals.putAll(elm.readPids(arr));
                }
            }
            for (int pid : known) {
                if (!vals.containsKey(pid)) put(vals, pid, elm.readPid(pid));
            }
            storeValues(vals);

            sb.append("موارد پشتیبانی‌شده (").append(known.size()).append("):\n");
            for (int pid : known) {
                PidCatalog.Pid def = PidCatalog.get(pid);
                double v = def.value(vals.get(pid));
                sb.append("✓ ").append(def.name).append(":  ").append(def.format(v)).append(" ").append(def.unit).append("\n");
            }
            List<String> unknown = new ArrayList<>();
            for (int pid : sup) {
                if (PidCatalog.get(pid) == null && pid % 0x20 != 0) unknown.add(String.format(Locale.US, "%02X", pid));
            }
            if (!unknown.isEmpty()) sb.append("\nPIDهای دیگر (بدون توضیح): ").append(TextUtils.join(" ", unknown)).append("\n");
            sb.append("\nبرای گذاشتن هر کدام روی داشبورد، روی یکی از کارت‌های پایین صفحه انگشت را نگه دارید.");

            StringBuilder csv = new StringBuilder();
            for (int pid : sup) csv.append(String.format(Locale.US, "%02X,", pid));
            prefs.edit().putString(KEY_SUPPORTED, csv.toString()).apply();
            supported = sup;
        } catch (IOException e) {
            sb.append("خطا: ").append(e.getMessage());
        }
        final String out = sb.toString();
        runOnUiThread(() -> result.setText(out));
    }

    // ============================================================ Dialogs

    /** Gear button: connect / scan / trouble codes / settings. */
    private void showMainMenu() {
        LinearLayout list = new LinearLayout(this);
        list.setOrientation(LinearLayout.VERTICAL);
        list.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        list.setPadding(dp(8), dp(10), dp(8), dp(10));
        GradientDrawable panel = new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM,
                new int[]{Color.parseColor("#1A222C"), Color.parseColor("#0E1319")});
        panel.setCornerRadius(dp(18));
        panel.setStroke(dp(1), Color.parseColor("#2A3542"));
        list.setBackground(panel);

        AlertDialog dlg = new AlertDialog.Builder(this).setView(list).create();
        if (running) {
            list.addView(menuRow(IconView.UNLINK, Color.parseColor("#FF6B6B"), "قطع اتصال", statusMsg, () -> {
                dlg.dismiss();
                disconnect();
            }));
        } else {
            list.addView(menuRow(IconView.LINK, CYAN, "اتصال به OBD", "بلوتوث، وای‌فای یا USB", () -> {
                dlg.dismiss();
                startConnectFlow();
            }));
        }
        list.addView(menuRow(IconView.RADAR, Color.parseColor("#B388FF"), "اسکن قابلیت‌ها",
                "شماره شاسی و همه‌ی اطلاعات قابل خواندن", () -> {
                    dlg.dismiss();
                    showScanDialog();
                }));
        list.addView(menuRow(IconView.WARNING, ORANGE, "کدهای خطا", "خواندن و پاک کردن", () -> {
            dlg.dismiss();
            showDtcDialog();
        }));
        list.addView(menuRow(IconView.GEAR, TEXT_DIM, "تنظیمات", "هشدارها، چیدمان، پس‌زمینه، وای‌فای", () -> {
            dlg.dismiss();
            showSettingsDialog();
        }));
        dlg.show();
        if (dlg.getWindow() != null) {
            dlg.getWindow().setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(Color.TRANSPARENT));
            dlg.getWindow().setLayout(dp(compactBar ? 320 : 380), -2);
        }
    }

    private View menuRow(int icon, int color, String title, String sub, Runnable action) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(dp(14), dp(12), dp(14), dp(12));
        android.graphics.drawable.StateListDrawable sel = new android.graphics.drawable.StateListDrawable();
        GradientDrawable pressedBg = new GradientDrawable();
        pressedBg.setColor(Color.parseColor("#22FFFFFF"));
        pressedBg.setCornerRadius(dp(12));
        sel.addState(new int[]{android.R.attr.state_pressed}, pressedBg);
        sel.addState(new int[]{}, new android.graphics.drawable.ColorDrawable(Color.TRANSPARENT));
        row.setBackground(sel);
        row.setClickable(true);
        row.setOnClickListener(v -> action.run());

        IconView iv = new IconView(this, icon, color, false);
        row.addView(iv, new LinearLayout.LayoutParams(dp(30), dp(30)));

        LinearLayout texts = new LinearLayout(this);
        texts.setOrientation(LinearLayout.VERTICAL);
        TextView t = new TextView(this);
        t.setText(title);
        t.setTextColor(Color.WHITE);
        t.setTextSize(17);
        t.setTypeface(Typeface.create("sans-serif-medium", Typeface.NORMAL));
        texts.addView(t);
        TextView st = new TextView(this);
        st.setText(sub);
        st.setTextColor(TEXT_DIM);
        st.setTextSize(12);
        st.setSingleLine(true);
        st.setEllipsize(TextUtils.TruncateAt.END);
        texts.addView(st);
        LinearLayout.LayoutParams tlp = new LinearLayout.LayoutParams(0, -2, 1f);
        tlp.setMarginStart(dp(14));
        row.addView(texts, tlp);
        return row;
    }

    private void showSettingsDialog() {
        ScrollView sv = new ScrollView(this);
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(24), dp(12), dp(24), dp(4));
        box.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        sv.addView(box);

        box.addView(settingLabel("هشدار دمای آب (°C) — بین ۸۰ تا ۱۳۰:"));
        EditText alarmEdit = numberField(alarmTemp);
        box.addView(alarmEdit);
        box.addView(settingLabel("تکرار هشدار دمای آب، هر چند دقیقه:"));
        EditText coolIntEdit = numberField(coolantIntervalMin);
        box.addView(coolIntEdit);

        box.addView(settingLabel("هشدار سرعت (km/h) — صفر یعنی خاموش:"));
        EditText speedEdit = numberField(speedAlarm);
        box.addView(speedEdit);
        box.addView(settingLabel("تکرار هشدار سرعت، هر چند دقیقه:"));
        EditText speedIntEdit = numberField(speedIntervalMin);
        box.addView(speedIntEdit);

        LinearLayout testRow = new LinearLayout(this);
        testRow.setOrientation(LinearLayout.HORIZONTAL);
        Button testSpeed = pill("تست صدای سرعت", CYAN);
        testSpeed.setOnClickListener(v -> alerts.playSpeedBeep());
        Button testCool = pill("تست صدای دمای آب", RED);
        testCool.setOnClickListener(v -> alerts.playDangerAlarm());
        testRow.addView(testSpeed, pillLp());
        testRow.addView(testCool, pillLp());
        LinearLayout.LayoutParams trlp = new LinearLayout.LayoutParams(-2, -2);
        trlp.setMargins(0, dp(8), 0, 0);
        box.addView(testRow, trlp);

        CheckBox auto = new CheckBox(this);
        auto.setText("اتصال خودکار به آخرین OBD هنگام باز شدن برنامه");
        auto.setChecked(prefs.getBoolean(KEY_AUTO, true));
        box.addView(auto);

        box.addView(settingLabel("آدرس OBD وای‌فای (معمولاً 192.168.0.10):"));
        EditText hostEdit = new EditText(this);
        hostEdit.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_URI);
        hostEdit.setText(wifiHost());
        hostEdit.setTextDirection(View.TEXT_DIRECTION_LTR);
        box.addView(hostEdit);
        box.addView(settingLabel("پورت وای‌فای (معمولاً 35000):"));
        EditText portEdit = new EditText(this);
        portEdit.setInputType(InputType.TYPE_CLASS_NUMBER);
        portEdit.setText(String.valueOf(wifiPort()));
        portEdit.setTextDirection(View.TEXT_DIRECTION_LTR);
        box.addView(portEdit);

        box.addView(settingLabel("چیدمان گیج‌ها (حالت افقی):"));
        final String[] layKeys = {"A", "B", "C", "D"};
        String[] layNames = {"کلاسیک سه‌تایی", "متقارن ۴+۱", "کلاستر اسپرت", "کلاستر اسپرت (گیج‌های گوشه درشت)"};
        android.widget.RadioGroup layGroup = new android.widget.RadioGroup(this);
        layGroup.setOrientation(LinearLayout.VERTICAL);
        String curLay = prefs.getString(KEY_LAYOUT, "B");
        for (int i = 0; i < layKeys.length; i++) {
            android.widget.RadioButton rb = new android.widget.RadioButton(this);
            rb.setText(layNames[i]);
            rb.setId(2000 + i);
            layGroup.addView(rb);
            if (layKeys[i].equals(curLay)) layGroup.check(2000 + i);
        }
        box.addView(layGroup);

        box.addView(settingLabel("طرح پس‌زمینه:"));
        final String[] bgKeys = {BackgroundView.CARBON, BackgroundView.HEX, BackgroundView.PLAIN};
        String[] bgNames = {"فیبر کربن", "شش‌ضلعی (کندو)", "ساده"};
        android.widget.RadioGroup bgGroup = new android.widget.RadioGroup(this);
        bgGroup.setOrientation(LinearLayout.HORIZONTAL);
        String curBg = prefs.getString(KEY_BG, BackgroundView.CARBON);
        for (int i = 0; i < bgKeys.length; i++) {
            android.widget.RadioButton rb = new android.widget.RadioButton(this);
            rb.setText(bgNames[i]);
            rb.setId(1000 + i);
            bgGroup.addView(rb);
            if (bgKeys[i].equals(curBg)) bgGroup.check(1000 + i);
        }
        box.addView(bgGroup);

        box.addView(settingLabel("نشان بالای صفحه:"));
        LinearLayout logoRow = new LinearLayout(this);
        logoRow.setOrientation(LinearLayout.HORIZONTAL);
        Button pick = pill("انتخاب عکس از گالری", CYAN);
        Button reset = pill("نشان پیش‌فرض", TEXT_DIM);
        logoRow.addView(pick, pillLp());
        logoRow.addView(reset, pillLp());
        box.addView(logoRow);

        AlertDialog dlg = new AlertDialog.Builder(this)
                .setTitle("تنظیمات")
                .setView(sv)
                .setPositiveButton("ذخیره", (d, w) -> {
                    try {
                        int v = Integer.parseInt(alarmEdit.getText().toString().trim());
                        int port = Integer.parseInt(portEdit.getText().toString().trim());
                        String host = hostEdit.getText().toString().trim();
                        if (v < 80 || v > 130) {
                            toast("دمای هشدار باید بین ۸۰ تا ۱۳۰ باشد");
                            return;
                        }
                        int sp = Integer.parseInt(speedEdit.getText().toString().trim());
                        int spInt = Integer.parseInt(speedIntEdit.getText().toString().trim());
                        int coInt = Integer.parseInt(coolIntEdit.getText().toString().trim());
                        if (sp != 0 && (sp < 20 || sp > 260)) {
                            toast("هشدار سرعت باید صفر یا بین ۲۰ تا ۲۶۰ باشد");
                            return;
                        }
                        if (spInt < 1 || spInt > 60 || coInt < 1 || coInt > 60) {
                            toast("فاصله‌ی تکرار باید بین ۱ تا ۶۰ دقیقه باشد");
                            return;
                        }
                        speedAlarm = sp;
                        speedIntervalMin = spInt;
                        coolantIntervalMin = coInt;
                        speedGauge.setRedFrom(sp > 0 ? sp : 140);
                        speedGauge.invalidate();
                        if (host.isEmpty() || port < 1 || port > 65535) {
                            toast("آدرس یا پورت وای‌فای درست نیست");
                            return;
                        }
                        alarmTemp = v;
                        coolantGauge.setRedFrom(v);
                        coolantBar.setWarnFrom(v);
                        coolantGauge.invalidate();
                        int sel = bgGroup.getCheckedRadioButtonId() - 1000;
                    String newBg = (sel >= 0 && sel < bgKeys.length) ? bgKeys[sel] : BackgroundView.CARBON;
                    int lsel = layGroup.getCheckedRadioButtonId() - 2000;
                    String newLay = (lsel >= 0 && lsel < layKeys.length) ? layKeys[lsel] : "B";
                    boolean bgChanged = !newBg.equals(prefs.getString(KEY_BG, BackgroundView.CARBON))
                            || !newLay.equals(prefs.getString(KEY_LAYOUT, "B"));
                    prefs.edit().putInt(KEY_ALARM, alarmTemp).putBoolean(KEY_AUTO, auto.isChecked())
                                .putInt(KEY_SPEED_ALARM, speedAlarm).putInt(KEY_SPEED_INT, speedIntervalMin)
                                .putInt(KEY_COOL_INT, coolantIntervalMin)
                                .putString(KEY_WIFI_HOST, host).putInt(KEY_WIFI_PORT, port)
                                .putString(KEY_BG, newBg).putString(KEY_LAYOUT, newLay).apply();
                    if (bgChanged) {
                        float pk = boostGauge.getPeak();
                        buildUi();
                        if (!Float.isNaN(pk)) boostGauge.setValue(pk);
                    }
                    } catch (NumberFormatException e) {
                        toast("عدد معتبر وارد کنید");
                        return;
                    }
                    applyValues();
                })
                .setNegativeButton("انصراف", null)
                .create();
        pick.setOnClickListener(v -> {
            dlg.dismiss();
            Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
            i.addCategory(Intent.CATEGORY_OPENABLE);
            i.setType("image/*");
            try {
                startActivityForResult(i, REQ_LOGO);
            } catch (Exception e) {
                toast("گالری باز نشد");
            }
        });
        reset.setOnClickListener(v -> {
            prefs.edit().remove(KEY_LOGO).apply();
            loadLogo();
            toast("نشان پیش‌فرض برگشت");
        });
        dlg.show();
    }

    private EditText numberField(int value) {
        EditText e = new EditText(this);
        e.setInputType(InputType.TYPE_CLASS_NUMBER);
        e.setText(String.valueOf(value));
        e.setTextDirection(View.TEXT_DIRECTION_LTR);
        return e;
    }

    private TextView settingLabel(String text) {
        TextView l = new TextView(this);
        l.setText(text);
        l.setTextColor(TEXT_DIM);
        l.setPadding(0, dp(12), 0, 0);
        return l;
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQ_LOGO && resultCode == RESULT_OK && data != null && data.getData() != null) {
            Uri uri = data.getData();
            try {
                getContentResolver().takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION);
            } catch (Exception ignored) {
            }
            prefs.edit().putString(KEY_LOGO, uri.toString()).apply();
            loadLogo();
        }
    }

    /** Shows the user's chosen image in the top bar, or the built-in emblem. */
    private void loadLogo() {
        if (badge == null) return;
        String s = prefs.getString(KEY_LOGO, "");
        Bitmap bmp = null;
        if (!s.isEmpty()) {
            try {
                Uri uri = Uri.parse(s);
                BitmapFactory.Options o = new BitmapFactory.Options();
                o.inJustDecodeBounds = true;
                try (InputStream in = getContentResolver().openInputStream(uri)) {
                    BitmapFactory.decodeStream(in, null, o);
                }
                int sample = 1;
                while (o.outWidth / (sample * 2) >= 256 && o.outHeight / (sample * 2) >= 256) sample *= 2;
                BitmapFactory.Options o2 = new BitmapFactory.Options();
                o2.inSampleSize = sample;
                try (InputStream in = getContentResolver().openInputStream(uri)) {
                    bmp = BitmapFactory.decodeStream(in, null, o2);
                }
            } catch (Exception e) {
                bmp = null;
            }
        }
        badge.setCustomImage(bmp);
    }

    private void showDtcDialog() {
        ScrollView sv = new ScrollView(this);
        TextView result = new TextView(this);
        result.setPadding(dp(24), dp(12), dp(24), dp(12));
        result.setTextSize(18);
        result.setTextColor(Color.WHITE);
        result.setTextIsSelectable(true);
        result.setText(running ? "برای خواندن کدها «خواندن» را بزنید." : "اول به OBD وصل شوید.");
        sv.addView(result);

        AlertDialog dlg = new AlertDialog.Builder(this)
                .setTitle("کدهای خطا")
                .setView(sv)
                .setPositiveButton("خواندن", null)
                .setNeutralButton("پاک کردن", null)
                .setNegativeButton("بستن", null)
                .create();
        dlg.setOnShowListener(d -> {
            dlg.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v -> {
                if (!running) {
                    toast("اول وصل شوید");
                    return;
                }
                result.setText("در حال خواندن...");
                jobs.offer(() -> readDtcs(result));
            });
            dlg.getButton(AlertDialog.BUTTON_NEUTRAL).setOnClickListener(v -> {
                if (!running) {
                    toast("اول وصل شوید");
                    return;
                }
                confirmClearDtcs(result);
            });
        });
        dlg.show();
    }

    private void confirmClearDtcs(TextView result) {
        new AlertDialog.Builder(this)
                .setTitle("پاک کردن کدهای خطا")
                .setMessage("موتور خاموش و سوییچ باز باشد.\n\nچراغ چک خاموش می‌شود، ولی اگر ایراد واقعی باشد دوباره روشن می‌شود. اطلاعات Freeze Frame و Readiness هم پاک می‌شود.\n\nادامه می‌دهید؟")
                .setPositiveButton("پاک کن", (d, w) -> {
                    result.setText("در حال پاک کردن...");
                    jobs.offer(() -> clearDtcs(result));
                })
                .setNegativeButton("انصراف", null)
                .show();
    }

    // ========================================================= Connections

    private boolean hasBtPermission() {
        if (Build.VERSION.SDK_INT >= 31) {
            return checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) == PackageManager.PERMISSION_GRANTED;
        }
        return true;
    }

    private BluetoothAdapter adapter() {
        BluetoothManager bm = (BluetoothManager) getSystemService(Context.BLUETOOTH_SERVICE);
        return bm == null ? null : bm.getAdapter();
    }

    private void startConnectFlow() {
        if (!hasBtPermission() && !btPermissionAsked) {
            btPermissionAsked = true;
            requestPermissions(new String[]{Manifest.permission.BLUETOOTH_CONNECT}, REQ_BT);
            return;
        }
        showDevicePicker();
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQ_BT) showDevicePicker();
    }

    private String wifiHost() {
        return prefs.getString(KEY_WIFI_HOST, "192.168.0.10");
    }

    private int wifiPort() {
        return prefs.getInt(KEY_WIFI_PORT, 35000);
    }

    private List<UsbSerialDriver> usbDrivers() {
        try {
            UsbManager um = (UsbManager) getSystemService(Context.USB_SERVICE);
            if (um == null) return new ArrayList<>();
            return UsbSerialProber.getDefaultProber().findAllDrivers(um);
        } catch (Exception e) {
            return new ArrayList<>();
        }
    }

    private static String usbKey(UsbDevice d) {
        return "usb:" + d.getVendorId() + ":" + d.getProductId();
    }

    /** One list with every way to connect: Bluetooth (paired), USB (plugged in) and Wi-Fi. */
    @SuppressLint("MissingPermission")
    private void showDevicePicker() {
        final List<String> keys = new ArrayList<>();
        final List<String> names = new ArrayList<>();
        String last = prefs.getString(KEY_LAST_DEVICE, "");

        List<UsbSerialDriver> drivers = usbDrivers();
        if (drivers.isEmpty()) {
            keys.add("usb-none");
            names.add("USB  —  کابل USB پیدا نشد");
        }
        for (UsbSerialDriver drv : drivers) {
            UsbDevice d = drv.getDevice();
            String n = d.getProductName() != null ? d.getProductName() : drv.getClass().getSimpleName().replace("SerialDriver", "");
            keys.add(usbKey(d));
            names.add("USB  —  " + n);
        }

        keys.add("wifi");
        names.add("Wi-Fi  —  " + wifiHost() + ":" + wifiPort());

        BluetoothAdapter a = adapter();
        if (a != null && a.isEnabled() && hasBtPermission()) {
            try {
                Set<BluetoothDevice> bonded = a.getBondedDevices();
                if (bonded != null) {
                    for (BluetoothDevice d : bonded) {
                        String n = d.getName() == null ? "(بی‌نام)" : d.getName();
                        keys.add("bt:" + d.getAddress());
                        names.add("بلوتوث  —  " + n + "   " + d.getAddress());
                    }
                }
            } catch (SecurityException ignored) {
            }
        }

        String[] arr = new String[names.size()];
        for (int i = 0; i < arr.length; i++) {
            arr[i] = names.get(i) + (keys.get(i).equals(last) ? "  ★" : "");
        }
        String hint = (a != null && !a.isEnabled()) ? "\n(بلوتوث خاموش است)" : "";
        new AlertDialog.Builder(this)
                .setTitle("اتصال به OBD" + hint)
                .setItems(arr, (dialog, which) -> {
                    if (keys.get(which).equals("usb-none")) showUsbHelp();
                    else connect(keys.get(which));
                })
                .setNegativeButton("انصراف", null)
                .show();
    }

    private void showUsbHelp() {
        int other = 0;
        try {
            UsbManager um = (UsbManager) getSystemService(Context.USB_SERVICE);
            if (um != null) other = um.getDeviceList().size();
        } catch (Exception ignored) {
        }
        String msg = "کابل OBD با USB پیدا نشد.\n\n"
                + "• کابل را به سوکت ماشین و به USB وصل کنید و سوییچ را باز کنید.\n"
                + "• کابل را جدا و دوباره وصل کنید، بعد دوباره «اتصال» را بزنید.\n"
                + "• اگر هد یونیت چند پورت USB دارد، پورت دیگر را امتحان کنید.\n"
                + "• روی گوشی به تبدیل OTG نیاز است.";
        if (other > 0) {
            msg += "\n\n" + other + " دستگاه USB دیگر وصل است ولی شبیه کابل OBD نیست "
                    + "(تراشه‌های پشتیبانی‌شده: CH340، FTDI، PL2303، CP210x).";
        }
        new AlertDialog.Builder(this)
                .setTitle("USB")
                .setMessage(msg)
                .setPositiveButton("باشه", null)
                .show();
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        handleUsbAttach(intent);
    }

    /** Opened because a USB OBD cable was plugged in: connect to it straight away. */
    @SuppressWarnings("deprecation")
    private boolean handleUsbAttach(Intent intent) {
        if (intent == null || !UsbManager.ACTION_USB_DEVICE_ATTACHED.equals(intent.getAction())) return false;
        UsbDevice dev;
        if (Build.VERSION.SDK_INT >= 33) dev = intent.getParcelableExtra(UsbManager.EXTRA_DEVICE, UsbDevice.class);
        else dev = intent.getParcelableExtra(UsbManager.EXTRA_DEVICE);
        if (dev == null) return false;
        String key = usbKey(dev);
        boolean isObd = false;
        for (UsbSerialDriver d : usbDrivers()) {
            if (usbKey(d.getDevice()).equals(key)) isObd = true;
        }
        if (!isObd) return false;
        if (running && key.equals(prefs.getString(KEY_LAST_DEVICE, ""))) return true; // already on it
        if (running) disconnect();
        toast("کابل USB وصل شد — در حال اتصال");
        connect(key);
        return true;
    }

    private void autoConnect() {
        String key = prefs.getString(KEY_LAST_DEVICE, "");
        if (key.isEmpty()) return;
        if (!key.startsWith("usb:") && !key.equals("wifi") && !hasBtPermission()) return;
        connect(key);
    }

    private void connect(String key) {
        prefs.edit().putString(KEY_LAST_DEVICE, key).apply();
        running = true;
        jobs.clear();
        updateConnectButton();
        worker = new Thread(() -> workerLoop(key), "obd-worker");
        worker.start();
    }

    private void disconnect() {
        running = false;
        if (worker != null) worker.interrupt();
        elm.close();
        clearValues();
        setStatus("قطع شد", Color.parseColor("#4A5562"));
    }

    private void clearValues() {
        vRpm = vSpeed = vBoost = vCoolant = vIat = vLoad = vThrottle = vVolt = Float.NaN;
        pidValues.clear();
        rateHz = 0;
        runOnUiThread(this::applyValues);
    }

    // ============================================================= Worker

    /** Keeps the connection alive: reconnects automatically after a drop. */
    /** True while this thread is the current, wanted worker (a newer connection supersedes it). */
    private boolean alive() {
        return running && Thread.currentThread() == worker;
    }

    private void workerLoop(String key) {
        while (alive()) {
            try {
                session(key);
            } catch (IOException e) {
                if (running) setStatus(e.getMessage() + " — تلاش دوباره...", ORANGE);
            } catch (RuntimeException e) {
                if (running) setStatus("خطا: " + e + " — تلاش دوباره...", ORANGE);
            } finally {
                if (alive()) elm.close();
            }
            if (!alive()) break;
            clearValues();
            try {
                Thread.sleep(3000);
            } catch (InterruptedException e) {
                break;
            }
        }
        runOnUiThread(this::updateConnectButton);
    }

    /** Opens the right kind of link for the saved key. */
    @SuppressLint("MissingPermission")
    private void openTransport(String key) throws IOException {
        if (key.equals("wifi")) {
            setStatus("در حال اتصال به " + wifiHost() + ":" + wifiPort() + " ...", ORANGE);
            ConnectivityManager cm = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
            elm.attach(new Transports.Wifi(cm, wifiHost(), wifiPort()));
            return;
        }
        if (key.startsWith("usb:")) {
            setStatus("در حال اتصال USB ...", ORANGE);
            UsbManager um = (UsbManager) getSystemService(Context.USB_SERVICE);
            UsbSerialDriver driver = null;
            for (UsbSerialDriver d : usbDrivers()) {
                if (usbKey(d.getDevice()).equals(key)) {
                    driver = d;
                    break;
                }
            }
            if (um == null || driver == null) throw new IOException("آداپتور USB وصل نیست");
            if (!um.hasPermission(driver.getDevice())) {
                Intent i = new Intent(ACTION_USB_PERMISSION).setPackage(getPackageName());
                int flags = Build.VERSION.SDK_INT >= 31 ? PendingIntent.FLAG_MUTABLE : 0;
                um.requestPermission(driver.getDevice(), PendingIntent.getBroadcast(this, 0, i, flags));
                setStatus("اجازه‌ی USB را روی صفحه تأیید کنید...", ORANGE);
                long end = System.currentTimeMillis() + 60000;
                while (!um.hasPermission(driver.getDevice())) {
                    if (!alive() || System.currentTimeMillis() > end) throw new IOException("اجازه‌ی USB داده نشد");
                    Transports.sleep(300);
                }
            }
            // ELM327 USB cables use 38400 by default; some are set to 115200 or 9600
            int[] bauds = {38400, 115200, 9600, 230400, 500000};
            for (int baud : bauds) {
                elm.attach(new Transports.Usb(um, driver, baud));
                if (elm.probe()) return;
            }
            throw new IOException("آداپتور USB جواب نداد");
        }
        // Bluetooth ("bt:ADDR", or a bare address saved by version 1)
        String addr = key.startsWith("bt:") ? key.substring(3) : key;
        BluetoothAdapter a = adapter();
        if (a == null || !a.isEnabled()) throw new IOException("بلوتوث خاموش است");
        if (!hasBtPermission()) throw new IOException("اجازه‌ی بلوتوث داده نشده");
        setStatus("در حال اتصال بلوتوث ...", ORANGE);
        BluetoothDevice dev = a.getRemoteDevice(addr);
        elm.attach(new Transports.Bluetooth(dev));
    }

    private void session(String key) throws IOException {
        openTransport(key);
        setStatus("در حال ارتباط با ECU (سوییچ باید باز باشد)...", ORANGE);
        String r = elm.init();
        if (ObdParser.pidData(r, 1, 0) == null) {
            throw new IOException("ECU جواب نداد: " + ObdParser.lines(r));
        }
        int[] baro = elm.readPid(0x33);
        if (baro != null && baro.length >= 1 && baro[0] > 50) baroKpa = baro[0];

        // Can we ask for several PIDs in one request? (much faster on CAN)
        boolean multi = false;
        if (elm.isCan()) {
            Map<Integer, int[]> m = elm.readPids(0x0C, 0x0D);
            multi = m.containsKey(0x0C) && m.containsKey(0x0D);
        }
        multiMode = multi;
        String via = key.equals("wifi") ? "Wi-Fi" : key.startsWith("usb:") ? "USB" : "بلوتوث";
        setStatus("وصل است — " + via + " · " + (elm.isCan() ? "CAN" : "K-Line") + (multi ? " · سریع" : ""), GREEN);

        int cycle = 0;
        int frames = 0;
        long windowStart = System.currentTimeMillis();
        while (alive()) {
            Runnable job = jobs.poll();
            if (job != null) {
                job.run();
                continue;
            }
            if (multi) pollMulti(cycle);
            else pollSingle(cycle);
            cycle++;
            frames++;

            long now = System.currentTimeMillis();
            if (now - windowStart >= 1000) {
                rateHz = frames * 1000f / (now - windowStart);
                frames = 0;
                windowStart = now;
            }
            if (cycle % 25 == 0) {
                double v = ObdParser.parseVoltage(elm.send("ATRV", 1500));
                vVolt = Double.isNaN(v) ? Float.NaN : (float) v;
            }
            runOnUiThread(this::applyValues);
            checkAlarms();
        }
    }

    private static final int[] FAST = {0x0C, 0x0D, 0x0B, 0x05};

    /** PIDs shown on tiles that are not already in the fast set. */
    private List<Integer> extraPids() {
        List<Integer> out = new ArrayList<>();
        for (String sl : slots) {
            if (!sl.startsWith("pid:")) continue;
            try {
                int pid = Integer.parseInt(sl.substring(4), 16);
                boolean fast = false;
                for (int f : FAST) if (f == pid) fast = true;
                if (!fast && !out.contains(pid)) out.add(pid);
            } catch (NumberFormatException ignored) {
            }
        }
        return out;
    }

    private void pollMulti(int cycle) throws IOException {
        storeValues(elm.readPids(FAST));
        if (cycle % 4 == 0) {
            List<Integer> extra = extraPids();
            for (int i = 0; i < extra.size(); i += 6) {
                List<Integer> chunk = extra.subList(i, Math.min(extra.size(), i + 6));
                int[] arr = new int[chunk.size()];
                for (int k = 0; k < arr.length; k++) arr[k] = chunk.get(k);
                storeValues(elm.readPids(arr));
            }
        }
    }

    private void pollSingle(int cycle) throws IOException {
        Map<Integer, int[]> m = new java.util.HashMap<>();
        int[] fast = {0x0C, 0x0B, 0x0D};
        for (int p : fast) put(m, p, elm.readPid(p));
        List<Integer> slow = new ArrayList<>();
        slow.add(0x05);
        slow.addAll(extraPids());
        int p = slow.get(cycle % slow.size());
        put(m, p, elm.readPid(p));
        storeValues(m);
    }

    private static void put(Map<Integer, int[]> m, int pid, int[] d) {
        if (d != null) m.put(pid, d);
    }

    private void storeValues(Map<Integer, int[]> m) {
        for (Map.Entry<Integer, int[]> e : m.entrySet()) {
            PidCatalog.Pid def = PidCatalog.get(e.getKey());
            if (def != null) {
                double v = def.value(e.getValue());
                if (!Double.isNaN(v)) pidValues.put(e.getKey(), v);
            }
        }
        int[] d;
        if ((d = m.get(0x0C)) != null && d.length >= 2) vRpm = (d[0] * 256 + d[1]) / 4f;
        if ((d = m.get(0x0D)) != null && d.length >= 1) {
            long now = System.currentTimeMillis();
            if (lastSpeedAt != 0 && !Float.isNaN(vSpeed) && now - lastSpeedAt < 5000) {
                // trip distance: average speed over the interval x time
                tripKm += (vSpeed + d[0]) / 2.0 * (now - lastSpeedAt) / 3600000.0;
            }
            lastSpeedAt = now;
            vSpeed = d[0];
        }
        if ((d = m.get(0x0B)) != null && d.length >= 1) vBoost = (d[0] - baroKpa) / 100f;
        if ((d = m.get(0x05)) != null && d.length >= 1) vCoolant = d[0] - 40;
        if ((d = m.get(0x0F)) != null && d.length >= 1) vIat = d[0] - 40;
        if ((d = m.get(0x04)) != null && d.length >= 1) vLoad = d[0] * 100f / 255f;
        if ((d = m.get(0x11)) != null && d.length >= 1) vThrottle = d[0] * 100f / 255f;
    }

    /**
     * Speed and coolant warnings. Each sounds once when its limit is reached, then repeats every
     * N minutes while the value stays above the limit. A small margin stops it re-arming on jitter.
     */
    private void checkAlarms() {
        long now = System.currentTimeMillis();
        float sp = vSpeed;
        if (speedAlarm > 0 && !Float.isNaN(sp)) {
            if (sp >= speedAlarm) {
                if (!speedAlertOn || now - lastSpeedAlert >= speedIntervalMin * 60000L) {
                    alerts.playSpeedBeep();
                    lastSpeedAlert = now;
                }
                speedAlertOn = true;
            } else if (sp < speedAlarm - 3) {
                speedAlertOn = false;
            }
        }
        float co = vCoolant;
        if (!Float.isNaN(co)) {
            if (co >= alarmTemp) {
                if (!coolantAlertOn || now - lastCoolantAlert >= coolantIntervalMin * 60000L) {
                    alerts.playDangerAlarm();
                    lastCoolantAlert = now;
                }
                coolantAlertOn = true;
            } else if (co < alarmTemp - 2) {
                coolantAlertOn = false;
            }
        }
    }

    // ================================================================ DTC

    private void readDtcs(TextView result) {
        String s;
        try {
            List<String> stored = ObdParser.parseDtcs(elm.send("03", 8000), 3, elm.isCan());
            List<String> pending = ObdParser.parseDtcs(elm.send("07", 8000), 7, elm.isCan());
            s = "کدهای ثبت‌شده:\n" + (stored.isEmpty() ? "ندارد ✓" : TextUtils.join("   ", stored))
                    + "\n\nکدهای در انتظار:\n" + (pending.isEmpty() ? "ندارد ✓" : TextUtils.join("   ", pending));
        } catch (IOException e) {
            s = "خطا: " + e.getMessage();
        }
        final String out = s;
        runOnUiThread(() -> result.setText(out));
    }

    private void clearDtcs(TextView result) {
        String s;
        try {
            String r = elm.send("04", 8000);
            s = r.toUpperCase().replace(" ", "").contains("44") ? "کدها پاک شد ✓"
                    : "ECU پاک کردن را قبول نکرد: " + ObdParser.lines(r);
        } catch (IOException e) {
            s = "خطا: " + e.getMessage();
        }
        final String out = s;
        runOnUiThread(() -> result.setText(out));
    }

    @Override
    protected void onDestroy() {
        running = false;
        if (worker != null) worker.interrupt();
        elm.close();
        if (alarmAnim != null) alarmAnim.cancel();
        if (alerts != null) alerts.release();
        super.onDestroy();
    }
}
