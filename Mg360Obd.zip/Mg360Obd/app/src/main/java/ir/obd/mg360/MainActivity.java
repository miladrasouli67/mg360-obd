package ir.obd.mg360;

import android.Manifest;
import android.animation.ObjectAnimator;
import android.animation.ValueAnimator;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.AlertDialog;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.content.res.Configuration;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.hardware.usb.UsbDevice;
import android.hardware.usb.UsbManager;
import android.media.AudioManager;
import android.net.ConnectivityManager;
import android.net.Uri;
import android.media.ToneGenerator;
import android.os.Build;
import android.os.Bundle;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.text.InputType;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import com.hoho.android.usbserial.driver.UsbSerialDriver;
import com.hoho.android.usbserial.driver.UsbSerialProber;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.LinkedBlockingQueue;

public class MainActivity extends Activity {

    private static final int REQ_BT = 1;
    private static final String PREFS = "settings";
    private static final String KEY_ALARM = "coolant_alarm";
    private static final String KEY_LAST_DEVICE = "last_device";
    private static final String KEY_AUTO = "auto_connect";
    private static final String KEY_WIFI_HOST = "wifi_host";
    private static final String KEY_WIFI_PORT = "wifi_port";
    private static final String KEY_LOGO = "logo_uri";
    private static final int REQ_LOGO = 2;
    private static final String ACTION_USB_PERMISSION = "ir.obd.mg360.USB_PERMISSION";

    // Colours
    private static final int BG = Color.parseColor("#06080B");
    private static final int TEXT_DIM = Color.parseColor("#8C98A6");
    private static final int GREEN = Color.parseColor("#00E676");
    private static final int ORANGE = Color.parseColor("#FFB020");
    private static final int RED = Color.parseColor("#FF3B30");
    private static final int CYAN = Color.parseColor("#00E5FF");

    // UI (rebuilt on rotation)
    private GaugeView rpmGauge, boostGauge, coolantGauge;
    private TileView speedTile, iatTile, loadTile, throttleTile, voltTile, peakTile;
    private TextView statusText, rateText;
    private View statusDot, alarmOverlay;
    private Button connectBtn;
    private ObjectAnimator alarmAnim;
    private TurboBadge badge;
    private boolean btPermissionAsked = false;

    // Latest readings (written by worker, read on UI thread). NaN = no data.
    private volatile float vRpm = Float.NaN, vSpeed = Float.NaN, vBoost = Float.NaN, vCoolant = Float.NaN,
            vIat = Float.NaN, vLoad = Float.NaN, vThrottle = Float.NaN, vVolt = Float.NaN;
    private volatile float rateHz = 0f;
    private volatile String statusMsg = "وصل نیست";
    private volatile int statusColor = Color.parseColor("#4A5562");

    // Connection
    private final Elm327 elm = new Elm327();
    private final LinkedBlockingQueue<Runnable> jobs = new LinkedBlockingQueue<>();
    private volatile boolean running = false;
    private Thread worker;
    private int baroKpa = 101;

    private int alarmTemp = 105;
    private long lastAlarmAt = 0;
    private boolean alarmActive = false;
    private ToneGenerator tone;
    private SharedPreferences prefs;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        getWindow().setStatusBarColor(BG);
        getWindow().setNavigationBarColor(BG);
        prefs = getSharedPreferences(PREFS, MODE_PRIVATE);
        alarmTemp = prefs.getInt(KEY_ALARM, 105);
        try {
            tone = new ToneGenerator(AudioManager.STREAM_ALARM, 100);
        } catch (RuntimeException e) {
            tone = null;
        }
        buildUi();
        applyValues();

        if (prefs.getBoolean(KEY_AUTO, true) && !prefs.getString(KEY_LAST_DEVICE, "").isEmpty()) {
            autoConnect();
        }
    }

    @Override
    public void onConfigurationChanged(Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
        float peak = boostGauge != null ? boostGauge.getPeak() : Float.NaN;
        buildUi();
        if (!Float.isNaN(peak)) boostGauge.setValue(peak); // restore peak marker
        applyValues();
    }

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus) hideSystemBars();
    }

    @SuppressWarnings("deprecation")
    private void hideSystemBars() {
        getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                        | View.SYSTEM_UI_FLAG_FULLSCREEN
                        | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                        | View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                        | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                        | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN);
    }

    // =================================================================== UI

    private void buildUi() {
        boolean landscape = getResources().getConfiguration().orientation == Configuration.ORIENTATION_LANDSCAPE;

        FrameLayout frame = new FrameLayout(this);
        GradientDrawable bgGrad = new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM,
                new int[]{Color.parseColor("#0D1218"), BG});
        frame.setBackground(bgGrad);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        root.setPadding(dp(10), dp(6), dp(10), dp(8));
        frame.addView(root, new FrameLayout.LayoutParams(-1, -1));

        root.addView(buildTopBar(), new LinearLayout.LayoutParams(-1, dp(52)));

        rpmGauge = new GaugeView(this, "RPM", "دور موتور", 0, 7000, 1000, 0,
                new int[]{CYAN, Color.parseColor("#2979FF"), Color.parseColor("#D500F9")})
                .setRedFrom(6000).setLabelDivider(1000);
        boostGauge = new GaugeView(this, "BOOST", "bar  فشار توربو", -1f, 2f, 0.5f, 2,
                new int[]{Color.parseColor("#2979FF"), GREEN, Color.parseColor("#FFEA00"),
                        Color.parseColor("#FF6D00"), Color.parseColor("#FF1744")})
                .setShowPeak(true);
        coolantGauge = new GaugeView(this, "COOLANT", "°C  دمای آب", 40, 130, 10, 0,
                new int[]{Color.parseColor("#2979FF"), CYAN, GREEN, Color.parseColor("#FFC400"),
                        Color.parseColor("#FF1744")})
                .setRedFrom(alarmTemp);

        speedTile = new TileView(this, "سرعت", "km/h", CYAN, false);
        iatTile = new TileView(this, "دمای هوای ورودی", "°C", Color.parseColor("#40C4FF"), false);
        loadTile = new TileView(this, "بار موتور", "%", Color.parseColor("#B388FF"), true);
        throttleTile = new TileView(this, "دریچه گاز", "%", GREEN, true);
        voltTile = new TileView(this, "ولتاژ باتری", "V", Color.parseColor("#FFD54F"), false);
        peakTile = new TileView(this, "بیشترین بوست", "bar", Color.parseColor("#FF6D00"), false);
        peakTile.setOnClickListener(v -> {
            boostGauge.resetPeak();
            peakTile.setValue("--");
            toast("بیشترین بوست صفر شد");
        });

        if (landscape) {
            LinearLayout gauges = new LinearLayout(this);
            gauges.setOrientation(LinearLayout.HORIZONTAL);
            gauges.setLayoutDirection(View.LAYOUT_DIRECTION_LTR);
            gauges.addView(rpmGauge, new LinearLayout.LayoutParams(0, -1, 1f));
            gauges.addView(boostGauge, new LinearLayout.LayoutParams(0, -1, 1.18f));
            gauges.addView(coolantGauge, new LinearLayout.LayoutParams(0, -1, 1f));
            root.addView(gauges, new LinearLayout.LayoutParams(-1, 0, 1f));

            LinearLayout tiles = new LinearLayout(this);
            tiles.setOrientation(LinearLayout.HORIZONTAL);
            for (TileView t : new TileView[]{speedTile, iatTile, loadTile, throttleTile, voltTile, peakTile}) {
                tiles.addView(t, new LinearLayout.LayoutParams(0, -1, 1f));
            }
            root.addView(tiles, new LinearLayout.LayoutParams(-1, 0, 0.30f));
        } else {
            root.addView(boostGauge, new LinearLayout.LayoutParams(-1, 0, 1.15f));
            LinearLayout row = new LinearLayout(this);
            row.setOrientation(LinearLayout.HORIZONTAL);
            row.setLayoutDirection(View.LAYOUT_DIRECTION_LTR);
            row.addView(rpmGauge, new LinearLayout.LayoutParams(0, -1, 1f));
            row.addView(coolantGauge, new LinearLayout.LayoutParams(0, -1, 1f));
            root.addView(row, new LinearLayout.LayoutParams(-1, 0, 0.8f));
            TileView[][] grid = {{speedTile, iatTile}, {loadTile, throttleTile}, {voltTile, peakTile}};
            for (TileView[] pair : grid) {
                LinearLayout r = new LinearLayout(this);
                r.setOrientation(LinearLayout.HORIZONTAL);
                for (TileView t : pair) r.addView(t, new LinearLayout.LayoutParams(0, -1, 1f));
                root.addView(r, new LinearLayout.LayoutParams(-1, 0, 0.17f));
            }
        }

        // Red pulsing border shown while the coolant alarm is active
        alarmOverlay = new View(this);
        GradientDrawable border = new GradientDrawable();
        border.setColor(Color.TRANSPARENT);
        border.setStroke(dp(8), RED);
        border.setCornerRadius(dp(4));
        alarmOverlay.setBackground(border);
        alarmOverlay.setVisibility(View.GONE);
        frame.addView(alarmOverlay, new FrameLayout.LayoutParams(-1, -1));
        alarmAnim = ObjectAnimator.ofFloat(alarmOverlay, "alpha", 1f, 0.15f);
        alarmAnim.setDuration(450);
        alarmAnim.setRepeatMode(ValueAnimator.REVERSE);
        alarmAnim.setRepeatCount(ValueAnimator.INFINITE);
        alarmActive = false;

        setContentView(frame);
        updateConnectButton();
        loadLogo();
    }

    private View buildTopBar() {
        LinearLayout bar = new LinearLayout(this);
        bar.setOrientation(LinearLayout.HORIZONTAL);
        bar.setGravity(Gravity.CENTER_VERTICAL);
        bar.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);

        TextView brand = new TextView(this);
        brand.setText("MG360 TURBO");
        brand.setTextColor(Color.WHITE);
        brand.setTextSize(18);
        brand.setLetterSpacing(0.15f);
        brand.setTypeface(Typeface.create("sans-serif-condensed", Typeface.BOLD));
        badge = new TurboBadge(this);
        LinearLayout.LayoutParams blp = new LinearLayout.LayoutParams(dp(44), dp(44));
        blp.setMargins(0, 0, 0, 0);
        bar.addView(badge, blp);
        LinearLayout.LayoutParams brlp = new LinearLayout.LayoutParams(-2, -2);
        brlp.setMarginStart(dp(10));
        bar.addView(brand, brlp);

        statusDot = new View(this);
        GradientDrawable dot = new GradientDrawable();
        dot.setShape(GradientDrawable.OVAL);
        dot.setColor(statusColor);
        statusDot.setBackground(dot);
        LinearLayout.LayoutParams dlp = new LinearLayout.LayoutParams(dp(10), dp(10));
        dlp.setMargins(dp(14), 0, dp(8), 0);
        bar.addView(statusDot, dlp);

        statusText = new TextView(this);
        statusText.setTextColor(TEXT_DIM);
        statusText.setTextSize(13);
        statusText.setSingleLine(true);
        statusText.setEllipsize(TextUtils.TruncateAt.END);
        statusText.setText(statusMsg);
        bar.addView(statusText, new LinearLayout.LayoutParams(0, -2, 1f));

        rateText = new TextView(this);
        rateText.setTextColor(Color.parseColor("#4A5562"));
        rateText.setTextSize(12);
        rateText.setTypeface(Typeface.MONOSPACE);
        LinearLayout.LayoutParams rlp = new LinearLayout.LayoutParams(-2, -2);
        rlp.setMargins(dp(8), 0, dp(8), 0);
        bar.addView(rateText, rlp);

        connectBtn = pill("اتصال", CYAN);
        connectBtn.setOnClickListener(v -> {
            if (running) disconnect();
            else startConnectFlow();
        });
        bar.addView(connectBtn, pillLp());

        Button dtcBtn = pill("کدهای خطا", ORANGE);
        dtcBtn.setOnClickListener(v -> showDtcDialog());
        bar.addView(dtcBtn, pillLp());

        Button settingsBtn = pill("تنظیمات", TEXT_DIM);
        settingsBtn.setOnClickListener(v -> showSettingsDialog());
        bar.addView(settingsBtn, pillLp());
        return bar;
    }

    private Button pill(String text, int color) {
        Button b = new Button(this);
        b.setText(text);
        b.setAllCaps(false);
        b.setTextSize(14);
        b.setTextColor(color);
        b.setMinHeight(0);
        b.setMinimumHeight(0);
        b.setPadding(dp(16), 0, dp(16), 0);
        b.setStateListAnimator(null);
        GradientDrawable g = new GradientDrawable();
        g.setColor(Color.parseColor("#121920"));
        g.setStroke(dp(1), (color & 0x00FFFFFF) | 0x66000000);
        g.setCornerRadius(dp(20));
        b.setBackground(g);
        return b;
    }

    private LinearLayout.LayoutParams pillLp() {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-2, dp(38));
        lp.setMargins(dp(4), 0, dp(4), 0);
        return lp;
    }

    private int dp(int v) {
        return Math.round(v * getResources().getDisplayMetrics().density);
    }

    private void toast(String s) {
        runOnUiThread(() -> Toast.makeText(this, s, Toast.LENGTH_SHORT).show());
    }

    private void setStatus(String msg, int color) {
        statusMsg = msg;
        statusColor = color;
        runOnUiThread(this::applyStatus);
    }

    private void applyStatus() {
        if (statusText == null) return;
        statusText.setText(statusMsg);
        ((GradientDrawable) statusDot.getBackground()).setColor(statusColor);
        updateConnectButton();
    }

    private void updateConnectButton() {
        if (connectBtn != null) connectBtn.setText(running ? "قطع" : "اتصال");
    }

    /** Pushes the latest readings into the views. Runs on the UI thread. */
    private void applyValues() {
        if (rpmGauge == null) return;
        rpmGauge.setValue(vRpm);
        boostGauge.setValue(vBoost);
        coolantGauge.setValue(vCoolant);

        speedTile.setValue(fmt0(vSpeed));
        iatTile.setValue(fmt0(vIat));
        loadTile.setValue(fmt0(vLoad));
        loadTile.setBar(Float.isNaN(vLoad) ? 0 : vLoad / 100f);
        throttleTile.setValue(fmt0(vThrottle));
        throttleTile.setBar(Float.isNaN(vThrottle) ? 0 : vThrottle / 100f);
        voltTile.setValue(Float.isNaN(vVolt) ? "--" : String.format(Locale.US, "%.1f", vVolt));
        voltTile.setValueColor(!Float.isNaN(vVolt) && (vVolt < 11.8f || vVolt > 14.9f) ? ORANGE : Color.WHITE);
        float peak = boostGauge.getPeak();
        peakTile.setValue(Float.isNaN(peak) ? "--" : String.format(Locale.US, "%+.2f", peak));

        if (iatTile != null) iatTile.setValueColor(!Float.isNaN(vIat) && vIat >= 60 ? ORANGE : Color.WHITE);

        badge.setIntensity(Float.isNaN(vBoost) ? 0f : vBoost / 1.5f);
        rateText.setText(running && rateHz > 0 ? String.format(Locale.US, "%.0f Hz", rateHz) : "");

        boolean hot = !Float.isNaN(vCoolant) && vCoolant >= alarmTemp;
        setAlarmVisual(hot);
    }

    private static String fmt0(float v) {
        return Float.isNaN(v) ? "--" : String.valueOf(Math.round(v));
    }

    private void setAlarmVisual(boolean on) {
        if (on == alarmActive) return;
        alarmActive = on;
        if (on) {
            alarmOverlay.setVisibility(View.VISIBLE);
            alarmAnim.start();
        } else {
            alarmAnim.cancel();
            alarmOverlay.setVisibility(View.GONE);
        }
    }

    // ============================================================ Dialogs

    private void showSettingsDialog() {
        ScrollView sv = new ScrollView(this);
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(24), dp(12), dp(24), dp(4));
        box.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        sv.addView(box);

        box.addView(settingLabel("هشدار دمای آب (°C) — بین ۸۰ تا ۱۳۰:"));
        EditText alarmEdit = new EditText(this);
        alarmEdit.setInputType(InputType.TYPE_CLASS_NUMBER);
        alarmEdit.setText(String.valueOf(alarmTemp));
        box.addView(alarmEdit);

        CheckBox auto = new CheckBox(this);
        auto.setText("اتصال خودکار به آخرین OBD هنگام باز شدن برنامه");
        auto.setChecked(prefs.getBoolean(KEY_AUTO, true));
        box.addView(auto);

        box.addView(settingLabel("آدرس OBD وای‌فای (معمولاً 192.168.0.10):"));
        EditText hostEdit = new EditText(this);
        hostEdit.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_URI);
        hostEdit.setText(wifiHost());
        hostEdit.setTextDirection(View.TEXT_DIRECTION_LTR);
        box.addView(hostEdit);
        box.addView(settingLabel("پورت وای‌فای (معمولاً 35000):"));
        EditText portEdit = new EditText(this);
        portEdit.setInputType(InputType.TYPE_CLASS_NUMBER);
        portEdit.setText(String.valueOf(wifiPort()));
        portEdit.setTextDirection(View.TEXT_DIRECTION_LTR);
        box.addView(portEdit);

        box.addView(settingLabel("نشان بالای صفحه:"));
        LinearLayout logoRow = new LinearLayout(this);
        logoRow.setOrientation(LinearLayout.HORIZONTAL);
        Button pick = pill("انتخاب عکس از گالری", CYAN);
        Button reset = pill("نشان پیش‌فرض", TEXT_DIM);
        logoRow.addView(pick, pillLp());
        logoRow.addView(reset, pillLp());
        box.addView(logoRow);

        AlertDialog dlg = new AlertDialog.Builder(this)
                .setTitle("تنظیمات")
                .setView(sv)
                .setPositiveButton("ذخیره", (d, w) -> {
                    try {
                        int v = Integer.parseInt(alarmEdit.getText().toString().trim());
                        int port = Integer.parseInt(portEdit.getText().toString().trim());
                        String host = hostEdit.getText().toString().trim();
                        if (v < 80 || v > 130) {
                            toast("دمای هشدار باید بین ۸۰ تا ۱۳۰ باشد");
                            return;
                        }
                        if (host.isEmpty() || port < 1 || port > 65535) {
                            toast("آدرس یا پورت وای‌فای درست نیست");
                            return;
                        }
                        alarmTemp = v;
                        coolantGauge.setRedFrom(v);
                        coolantGauge.invalidate();
                        prefs.edit().putInt(KEY_ALARM, alarmTemp).putBoolean(KEY_AUTO, auto.isChecked())
                                .putString(KEY_WIFI_HOST, host).putInt(KEY_WIFI_PORT, port).apply();
                    } catch (NumberFormatException e) {
                        toast("عدد معتبر وارد کنید");
                        return;
                    }
                    applyValues();
                })
                .setNegativeButton("انصراف", null)
                .create();
        pick.setOnClickListener(v -> {
            dlg.dismiss();
            Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
            i.addCategory(Intent.CATEGORY_OPENABLE);
            i.setType("image/*");
            try {
                startActivityForResult(i, REQ_LOGO);
            } catch (Exception e) {
                toast("گالری باز نشد");
            }
        });
        reset.setOnClickListener(v -> {
            prefs.edit().remove(KEY_LOGO).apply();
            loadLogo();
            toast("نشان پیش‌فرض برگشت");
        });
        dlg.show();
    }

    private TextView settingLabel(String text) {
        TextView l = new TextView(this);
        l.setText(text);
        l.setTextColor(TEXT_DIM);
        l.setPadding(0, dp(12), 0, 0);
        return l;
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQ_LOGO && resultCode == RESULT_OK && data != null && data.getData() != null) {
            Uri uri = data.getData();
            try {
                getContentResolver().takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION);
            } catch (Exception ignored) {
            }
            prefs.edit().putString(KEY_LOGO, uri.toString()).apply();
            loadLogo();
        }
    }

    /** Shows the user's chosen image in the top bar, or the built-in emblem. */
    private void loadLogo() {
        if (badge == null) return;
        String s = prefs.getString(KEY_LOGO, "");
        Bitmap bmp = null;
        if (!s.isEmpty()) {
            try {
                Uri uri = Uri.parse(s);
                BitmapFactory.Options o = new BitmapFactory.Options();
                o.inJustDecodeBounds = true;
                try (InputStream in = getContentResolver().openInputStream(uri)) {
                    BitmapFactory.decodeStream(in, null, o);
                }
                int sample = 1;
                while (o.outWidth / (sample * 2) >= 256 && o.outHeight / (sample * 2) >= 256) sample *= 2;
                BitmapFactory.Options o2 = new BitmapFactory.Options();
                o2.inSampleSize = sample;
                try (InputStream in = getContentResolver().openInputStream(uri)) {
                    bmp = BitmapFactory.decodeStream(in, null, o2);
                }
            } catch (Exception e) {
                bmp = null;
            }
        }
        badge.setCustomImage(bmp);
    }

    private void showDtcDialog() {
        ScrollView sv = new ScrollView(this);
        TextView result = new TextView(this);
        result.setPadding(dp(24), dp(12), dp(24), dp(12));
        result.setTextSize(18);
        result.setTextColor(Color.WHITE);
        result.setTextIsSelectable(true);
        result.setText(running ? "برای خواندن کدها «خواندن» را بزنید." : "اول به OBD وصل شوید.");
        sv.addView(result);

        AlertDialog dlg = new AlertDialog.Builder(this)
                .setTitle("کدهای خطا")
                .setView(sv)
                .setPositiveButton("خواندن", null)
                .setNeutralButton("پاک کردن", null)
                .setNegativeButton("بستن", null)
                .create();
        dlg.setOnShowListener(d -> {
            dlg.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v -> {
                if (!running) {
                    toast("اول وصل شوید");
                    return;
                }
                result.setText("در حال خواندن...");
                jobs.offer(() -> readDtcs(result));
            });
            dlg.getButton(AlertDialog.BUTTON_NEUTRAL).setOnClickListener(v -> {
                if (!running) {
                    toast("اول وصل شوید");
                    return;
                }
                confirmClearDtcs(result);
            });
        });
        dlg.show();
    }

    private void confirmClearDtcs(TextView result) {
        new AlertDialog.Builder(this)
                .setTitle("پاک کردن کدهای خطا")
                .setMessage("موتور خاموش و سوییچ باز باشد.\n\nچراغ چک خاموش می‌شود، ولی اگر ایراد واقعی باشد دوباره روشن می‌شود. اطلاعات Freeze Frame و Readiness هم پاک می‌شود.\n\nادامه می‌دهید؟")
                .setPositiveButton("پاک کن", (d, w) -> {
                    result.setText("در حال پاک کردن...");
                    jobs.offer(() -> clearDtcs(result));
                })
                .setNegativeButton("انصراف", null)
                .show();
    }

    // ========================================================= Connections

    private boolean hasBtPermission() {
        if (Build.VERSION.SDK_INT >= 31) {
            return checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) == PackageManager.PERMISSION_GRANTED;
        }
        return true;
    }

    private BluetoothAdapter adapter() {
        BluetoothManager bm = (BluetoothManager) getSystemService(Context.BLUETOOTH_SERVICE);
        return bm == null ? null : bm.getAdapter();
    }

    private void startConnectFlow() {
        if (!hasBtPermission() && !btPermissionAsked) {
            btPermissionAsked = true;
            requestPermissions(new String[]{Manifest.permission.BLUETOOTH_CONNECT}, REQ_BT);
            return;
        }
        showDevicePicker();
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQ_BT) showDevicePicker();
    }

    private String wifiHost() {
        return prefs.getString(KEY_WIFI_HOST, "192.168.0.10");
    }

    private int wifiPort() {
        return prefs.getInt(KEY_WIFI_PORT, 35000);
    }

    private List<UsbSerialDriver> usbDrivers() {
        try {
            UsbManager um = (UsbManager) getSystemService(Context.USB_SERVICE);
            if (um == null) return new ArrayList<>();
            return UsbSerialProber.getDefaultProber().findAllDrivers(um);
        } catch (Exception e) {
            return new ArrayList<>();
        }
    }

    private static String usbKey(UsbDevice d) {
        return "usb:" + d.getVendorId() + ":" + d.getProductId();
    }

    /** One list with every way to connect: Bluetooth (paired), USB (plugged in) and Wi-Fi. */
    @SuppressLint("MissingPermission")
    private void showDevicePicker() {
        final List<String> keys = new ArrayList<>();
        final List<String> names = new ArrayList<>();
        String last = prefs.getString(KEY_LAST_DEVICE, "");

        for (UsbSerialDriver drv : usbDrivers()) {
            UsbDevice d = drv.getDevice();
            String n = d.getProductName() != null ? d.getProductName() : drv.getClass().getSimpleName().replace("SerialDriver", "");
            keys.add(usbKey(d));
            names.add("USB  —  " + n);
        }

        keys.add("wifi");
        names.add("Wi-Fi  —  " + wifiHost() + ":" + wifiPort());

        BluetoothAdapter a = adapter();
        if (a != null && a.isEnabled() && hasBtPermission()) {
            try {
                Set<BluetoothDevice> bonded = a.getBondedDevices();
                if (bonded != null) {
                    for (BluetoothDevice d : bonded) {
                        String n = d.getName() == null ? "(بی‌نام)" : d.getName();
                        keys.add("bt:" + d.getAddress());
                        names.add("بلوتوث  —  " + n + "   " + d.getAddress());
                    }
                }
            } catch (SecurityException ignored) {
            }
        }

        String[] arr = new String[names.size()];
        for (int i = 0; i < arr.length; i++) {
            arr[i] = names.get(i) + (keys.get(i).equals(last) ? "  ★" : "");
        }
        String hint = (a != null && !a.isEnabled()) ? "\n(بلوتوث خاموش است)" : "";
        new AlertDialog.Builder(this)
                .setTitle("اتصال به OBD" + hint)
                .setItems(arr, (dialog, which) -> connect(keys.get(which)))
                .setNegativeButton("انصراف", null)
                .show();
    }

    private void autoConnect() {
        String key = prefs.getString(KEY_LAST_DEVICE, "");
        if (key.isEmpty()) return;
        if (!key.startsWith("usb:") && !key.equals("wifi") && !hasBtPermission()) return;
        connect(key);
    }

    private void connect(String key) {
        prefs.edit().putString(KEY_LAST_DEVICE, key).apply();
        running = true;
        jobs.clear();
        updateConnectButton();
        worker = new Thread(() -> workerLoop(key), "obd-worker");
        worker.start();
    }

    private void disconnect() {
        running = false;
        if (worker != null) worker.interrupt();
        elm.close();
        clearValues();
        setStatus("قطع شد", Color.parseColor("#4A5562"));
    }

    private void clearValues() {
        vRpm = vSpeed = vBoost = vCoolant = vIat = vLoad = vThrottle = vVolt = Float.NaN;
        rateHz = 0;
        runOnUiThread(this::applyValues);
    }

    // ============================================================= Worker

    /** Keeps the connection alive: reconnects automatically after a drop. */
    private void workerLoop(String key) {
        while (running) {
            try {
                session(key);
            } catch (IOException e) {
                if (running) setStatus(e.getMessage() + " — تلاش دوباره...", ORANGE);
            } catch (RuntimeException e) {
                if (running) setStatus("خطا: " + e + " — تلاش دوباره...", ORANGE);
            } finally {
                elm.close();
            }
            if (!running) break;
            clearValues();
            try {
                Thread.sleep(3000);
            } catch (InterruptedException e) {
                break;
            }
        }
        runOnUiThread(this::updateConnectButton);
    }

    /** Opens the right kind of link for the saved key. */
    @SuppressLint("MissingPermission")
    private void openTransport(String key) throws IOException {
        if (key.equals("wifi")) {
            setStatus("در حال اتصال به " + wifiHost() + ":" + wifiPort() + " ...", ORANGE);
            ConnectivityManager cm = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
            elm.attach(new Transports.Wifi(cm, wifiHost(), wifiPort()));
            return;
        }
        if (key.startsWith("usb:")) {
            setStatus("در حال اتصال USB ...", ORANGE);
            UsbManager um = (UsbManager) getSystemService(Context.USB_SERVICE);
            UsbSerialDriver driver = null;
            for (UsbSerialDriver d : usbDrivers()) {
                if (usbKey(d.getDevice()).equals(key)) {
                    driver = d;
                    break;
                }
            }
            if (um == null || driver == null) throw new IOException("آداپتور USB وصل نیست");
            if (!um.hasPermission(driver.getDevice())) {
                Intent i = new Intent(ACTION_USB_PERMISSION).setPackage(getPackageName());
                int flags = Build.VERSION.SDK_INT >= 31 ? PendingIntent.FLAG_MUTABLE : 0;
                um.requestPermission(driver.getDevice(), PendingIntent.getBroadcast(this, 0, i, flags));
                setStatus("اجازه‌ی USB را روی صفحه تأیید کنید...", ORANGE);
                long end = System.currentTimeMillis() + 60000;
                while (!um.hasPermission(driver.getDevice())) {
                    if (!running || System.currentTimeMillis() > end) throw new IOException("اجازه‌ی USB داده نشد");
                    Transports.sleep(300);
                }
            }
            // ELM327 USB cables use 38400 by default; some are set to 115200 or 9600
            int[] bauds = {38400, 115200, 9600, 230400, 500000};
            for (int baud : bauds) {
                elm.attach(new Transports.Usb(um, driver, baud));
                if (elm.probe()) return;
            }
            throw new IOException("آداپتور USB جواب نداد");
        }
        // Bluetooth ("bt:ADDR", or a bare address saved by version 1)
        String addr = key.startsWith("bt:") ? key.substring(3) : key;
        BluetoothAdapter a = adapter();
        if (a == null || !a.isEnabled()) throw new IOException("بلوتوث خاموش است");
        if (!hasBtPermission()) throw new IOException("اجازه‌ی بلوتوث داده نشده");
        setStatus("در حال اتصال بلوتوث ...", ORANGE);
        BluetoothDevice dev = a.getRemoteDevice(addr);
        elm.attach(new Transports.Bluetooth(dev));
    }

    private void session(String key) throws IOException {
        openTransport(key);
        setStatus("در حال ارتباط با ECU (سوییچ باید باز باشد)...", ORANGE);
        String r = elm.init();
        if (ObdParser.pidData(r, 1, 0) == null) {
            throw new IOException("ECU جواب نداد: " + ObdParser.lines(r));
        }
        int[] baro = elm.readPid(0x33);
        if (baro != null && baro.length >= 1 && baro[0] > 50) baroKpa = baro[0];

        // Can we ask for several PIDs in one request? (much faster on CAN)
        boolean multi = false;
        if (elm.isCan()) {
            Map<Integer, int[]> m = elm.readPids(0x0C, 0x0D);
            multi = m.containsKey(0x0C) && m.containsKey(0x0D);
        }
        String via = key.equals("wifi") ? "Wi-Fi" : key.startsWith("usb:") ? "USB" : "بلوتوث";
        setStatus("وصل است — " + via + " · " + (elm.isCan() ? "CAN" : "K-Line") + (multi ? " · سریع" : ""), GREEN);

        int cycle = 0;
        int frames = 0;
        long windowStart = System.currentTimeMillis();
        while (running) {
            Runnable job = jobs.poll();
            if (job != null) {
                job.run();
                continue;
            }
            if (multi) pollMulti(cycle);
            else pollSingle(cycle);
            cycle++;
            frames++;

            long now = System.currentTimeMillis();
            if (now - windowStart >= 1000) {
                rateHz = frames * 1000f / (now - windowStart);
                frames = 0;
                windowStart = now;
            }
            if (cycle % 25 == 0) {
                double v = ObdParser.parseVoltage(elm.send("ATRV", 1500));
                vVolt = Double.isNaN(v) ? Float.NaN : (float) v;
            }
            runOnUiThread(this::applyValues);
            if (!Float.isNaN(vCoolant)) checkAlarm(vCoolant);
        }
    }

    private void pollMulti(int cycle) throws IOException {
        Map<Integer, int[]> m = elm.readPids(0x0C, 0x0D, 0x0B, 0x05);
        storeValues(m);
        if (cycle % 4 == 0) storeValues(elm.readPids(0x0F, 0x04, 0x11));
    }

    private void pollSingle(int cycle) throws IOException {
        Map<Integer, int[]> m = new java.util.HashMap<>();
        int[] fast = {0x0C, 0x0B, 0x0D};
        for (int p : fast) put(m, p, elm.readPid(p));
        int[] slow = {0x05, 0x0F, 0x04, 0x11};
        int p = slow[cycle % slow.length];
        put(m, p, elm.readPid(p));
        storeValues(m);
    }

    private static void put(Map<Integer, int[]> m, int pid, int[] d) {
        if (d != null) m.put(pid, d);
    }

    private void storeValues(Map<Integer, int[]> m) {
        int[] d;
        if ((d = m.get(0x0C)) != null && d.length >= 2) vRpm = (d[0] * 256 + d[1]) / 4f;
        if ((d = m.get(0x0D)) != null && d.length >= 1) vSpeed = d[0];
        if ((d = m.get(0x0B)) != null && d.length >= 1) vBoost = (d[0] - baroKpa) / 100f;
        if ((d = m.get(0x05)) != null && d.length >= 1) vCoolant = d[0] - 40;
        if ((d = m.get(0x0F)) != null && d.length >= 1) vIat = d[0] - 40;
        if ((d = m.get(0x04)) != null && d.length >= 1) vLoad = d[0] * 100f / 255f;
        if ((d = m.get(0x11)) != null && d.length >= 1) vThrottle = d[0] * 100f / 255f;
    }

    @SuppressWarnings("deprecation")
    private void checkAlarm(float coolant) {
        if (coolant < alarmTemp) return;
        long now = System.currentTimeMillis();
        if (now - lastAlarmAt < 5000) return;
        lastAlarmAt = now;
        if (tone != null) tone.startTone(ToneGenerator.TONE_CDMA_ALERT_CALL_GUARD, 800);
        Vibrator vib = (Vibrator) getSystemService(Context.VIBRATOR_SERVICE);
        if (vib != null && vib.hasVibrator()) {
            if (Build.VERSION.SDK_INT >= 26) vib.vibrate(VibrationEffect.createOneShot(600, VibrationEffect.DEFAULT_AMPLITUDE));
            else vib.vibrate(600);
        }
    }

    // ================================================================ DTC

    private void readDtcs(TextView result) {
        String s;
        try {
            List<String> stored = ObdParser.parseDtcs(elm.send("03", 8000), 3, elm.isCan());
            List<String> pending = ObdParser.parseDtcs(elm.send("07", 8000), 7, elm.isCan());
            s = "کدهای ثبت‌شده:\n" + (stored.isEmpty() ? "ندارد ✓" : TextUtils.join("   ", stored))
                    + "\n\nکدهای در انتظار:\n" + (pending.isEmpty() ? "ندارد ✓" : TextUtils.join("   ", pending));
        } catch (IOException e) {
            s = "خطا: " + e.getMessage();
        }
        final String out = s;
        runOnUiThread(() -> result.setText(out));
    }

    private void clearDtcs(TextView result) {
        String s;
        try {
            String r = elm.send("04", 8000);
            s = r.toUpperCase().replace(" ", "").contains("44") ? "کدها پاک شد ✓"
                    : "ECU پاک کردن را قبول نکرد: " + ObdParser.lines(r);
        } catch (IOException e) {
            s = "خطا: " + e.getMessage();
        }
        final String out = s;
        runOnUiThread(() -> result.setText(out));
    }

    @Override
    protected void onDestroy() {
        running = false;
        if (worker != null) worker.interrupt();
        elm.close();
        if (alarmAnim != null) alarmAnim.cancel();
        if (tone != null) tone.release();
        super.onDestroy();
    }
}
