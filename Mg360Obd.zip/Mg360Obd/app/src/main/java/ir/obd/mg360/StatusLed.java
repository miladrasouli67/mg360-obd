package ir.obd.mg360;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RadialGradient;
import android.graphics.Shader;
import android.view.View;

/** Small glowing LED: green = connected, orange = connecting, red = not connected. */
public class StatusLed extends View {

    private int color = Color.parseColor("#FF3B30");
    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);

    public StatusLed(Context ctx) {
        super(ctx);
    }

    public void setColor(int c) {
        color = c;
        invalidate();
    }

    @Override
    protected void onDraw(Canvas c) {
        super.onDraw(c);
        float cx = getWidth() / 2f, cy = getHeight() / 2f, r = Math.min(cx, cy);
        // outer glow
        p.setShader(new RadialGradient(cx, cy, r, new int[]{(color & 0x00FFFFFF) | 0x88000000, color & 0x00FFFFFF},
                null, Shader.TileMode.CLAMP));
        c.drawCircle(cx, cy, r, p);
        // core with a small highlight
        p.setShader(new RadialGradient(cx - r * 0.12f, cy - r * 0.12f, r * 0.42f,
                new int[]{Color.WHITE, color, (color & 0x00FFFFFF) | 0xFF000000}, new float[]{0f, 0.45f, 1f},
                Shader.TileMode.CLAMP));
        c.drawCircle(cx, cy, r * 0.40f, p);
    }
}
