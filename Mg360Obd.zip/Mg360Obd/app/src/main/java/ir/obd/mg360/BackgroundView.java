package ir.obd.mg360;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapShader;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RadialGradient;
import android.graphics.Shader;
import android.view.View;

/**
 * Dashboard background: dark base, a repeating pattern (carbon fibre or hexagon grid),
 * soft coloured glows and a vignette. Drawn once into a bitmap, so it costs nothing per frame.
 */
public class BackgroundView extends View {

    public static final String CARBON = "carbon";
    public static final String HEX = "hex";
    public static final String PLAIN = "plain";

    private String style = CARBON;
    private Bitmap cache;

    public BackgroundView(Context ctx) {
        super(ctx);
    }

    public void setStyle(String s) {
        style = s == null ? CARBON : s;
        cache = null;
        invalidate();
    }

    @Override
    protected void onSizeChanged(int w, int h, int ow, int oh) {
        super.onSizeChanged(w, h, ow, oh);
        cache = null;
    }

    @Override
    protected void onDraw(Canvas c) {
        super.onDraw(c);
        int w = getWidth(), h = getHeight();
        if (w <= 0 || h <= 0) return;
        if (cache == null || cache.getWidth() != w || cache.getHeight() != h) {
            try {
                cache = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
                render(new Canvas(cache), w, h);
            } catch (OutOfMemoryError e) {
                cache = null;
                render(c, w, h);
                return;
            }
        }
        c.drawBitmap(cache, 0, 0, null);
    }

    private float dp(float v) {
        return v * getResources().getDisplayMetrics().density;
    }

    private void render(Canvas c, int w, int h) {
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);

        // 1. base
        p.setShader(new LinearGradient(0, 0, 0, h, Color.parseColor("#0E141B"), Color.parseColor("#05070A"),
                Shader.TileMode.CLAMP));
        c.drawRect(0, 0, w, h, p);

        // 2. pattern
        if (CARBON.equals(style)) drawCarbon(c, w, h);
        else if (HEX.equals(style)) drawHex(c, w, h);

        // 3. coloured glows (cyan top-left, orange bottom-right, violet centre)
        glow(c, w * 0.12f, h * 0.10f, Math.max(w, h) * 0.55f, Color.parseColor("#00E5FF"), 0x22);
        glow(c, w * 0.92f, h * 0.95f, Math.max(w, h) * 0.50f, Color.parseColor("#FF6D00"), 0x1C);
        glow(c, w * 0.50f, h * 0.45f, Math.max(w, h) * 0.45f, Color.parseColor("#7C4DFF"), 0x10);

        // 4. vignette
        p.setShader(new RadialGradient(w / 2f, h / 2f, (float) Math.hypot(w, h) * 0.6f,
                new int[]{0x00000000, 0x00000000, 0xB0000000}, new float[]{0f, 0.55f, 1f}, Shader.TileMode.CLAMP));
        c.drawRect(0, 0, w, h, p);

        // 5. thin light line along the top edge
        p.setShader(new LinearGradient(0, 0, w, 0,
                new int[]{0x0000E5FF, 0x5500E5FF, 0x00FF6D00}, null, Shader.TileMode.CLAMP));
        c.drawRect(0, 0, w, dp(1.5f), p);
    }

    private void glow(Canvas c, float x, float y, float r, int color, int alpha) {
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        int col = (color & 0x00FFFFFF) | (alpha << 24);
        p.setShader(new RadialGradient(x, y, r, new int[]{col, color & 0x00FFFFFF}, null, Shader.TileMode.CLAMP));
        c.drawCircle(x, y, r, p);
    }

    /** Twill-weave carbon fibre: a small tile of light/dark strands, repeated. */
    private void drawCarbon(Canvas c, int w, int h) {
        int cell = Math.max(4, Math.round(dp(5)));
        int size = cell * 4;
        Bitmap tile = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888);
        Canvas t = new Canvas(tile);
        Paint s = new Paint(Paint.ANTI_ALIAS_FLAG);
        for (int row = 0; row < 4; row++) {
            for (int col = 0; col < 4; col++) {
                // 2x2 twill: the strand direction shifts by one cell per row
                boolean horizontal = ((col + row) % 4) < 2;
                float x0 = col * cell, y0 = row * cell;
                if (horizontal) {
                    s.setShader(new LinearGradient(x0, y0, x0, y0 + cell,
                            new int[]{0xFF1A222B, 0xFF27313C, 0xFF12181F}, null, Shader.TileMode.CLAMP));
                } else {
                    s.setShader(new LinearGradient(x0, y0, x0 + cell, y0,
                            new int[]{0xFF10151B, 0xFF1C242D, 0xFF0C1015}, null, Shader.TileMode.CLAMP));
                }
                t.drawRect(x0, y0, x0 + cell, y0 + cell, s);
            }
        }
        Paint p = new Paint();
        p.setShader(new BitmapShader(tile, Shader.TileMode.REPEAT, Shader.TileMode.REPEAT));
        p.setAlpha(0x8C);
        c.drawRect(0, 0, w, h, p);

        // subtle diagonal sheen so the weave looks glossy
        Paint sheen = new Paint(Paint.ANTI_ALIAS_FLAG);
        sheen.setShader(new LinearGradient(0, 0, w, h,
                new int[]{0x00FFFFFF, 0x0EFFFFFF, 0x00FFFFFF, 0x0AFFFFFF, 0x00FFFFFF}, null, Shader.TileMode.CLAMP));
        c.drawRect(0, 0, w, h, sheen);
    }

    /** Honeycomb grid of thin lines, brighter towards the centre. */
    private void drawHex(Canvas c, int w, int h) {
        float r = dp(18);
        float hw = (float) (Math.sqrt(3) * r);
        Paint line = new Paint(Paint.ANTI_ALIAS_FLAG);
        line.setStyle(Paint.Style.STROKE);
        line.setStrokeWidth(dp(1));
        line.setShader(new RadialGradient(w / 2f, h / 2f, Math.max(w, h) * 0.7f,
                new int[]{0x3000E5FF, 0x1A2979FF, 0x08000000}, null, Shader.TileMode.CLAMP));
        Path hex = new Path();
        int rowIdx = 0;
        for (float y = -r; y < h + 2 * r; y += r * 1.5f, rowIdx++) {
            float offset = (rowIdx % 2) * hw / 2f;
            for (float x = -hw + offset; x < w + hw; x += hw) {
                hex.reset();
                for (int k = 0; k < 6; k++) {
                    double a = Math.toRadians(60 * k - 30);
                    float px = x + (float) Math.cos(a) * r * 0.94f, py = y + (float) Math.sin(a) * r * 0.94f;
                    if (k == 0) hex.moveTo(px, py);
                    else hex.lineTo(px, py);
                }
                hex.close();
                c.drawPath(hex, line);
            }
        }
    }
}
